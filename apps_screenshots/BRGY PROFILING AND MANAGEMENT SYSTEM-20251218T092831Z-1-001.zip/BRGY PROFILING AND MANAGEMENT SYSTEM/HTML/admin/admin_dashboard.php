<?php require_once __DIR__ . '/../../PHP/auth_guard.php'; require_login(['admin']); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard | Barangay Profiling</title>
  <link rel="stylesheet" href="../../CSS/dashboard_layout.css" />
  <link rel="stylesheet" href="../../CSS/admin_dashboard.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-8l0Vg5S1m3n3S6WQ0TRl3i+qkqY8Y3+u0Hn1g8kN2vFQwI3r8jYkDq7W5kF3nJf7hH9Y3C5w7lYw+8F0y0xjQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <aside class="sidebar">
    <div class="brand">
      <img src="../../assets/images/logo.png" alt="Logo" />
      <h1>Barangay Profiling</h1>
    </div>
    <nav class="nav" aria-label="Admin Navigation">
      <a href="#" class="active" data-target="sec-overview" title="Dashboard Overview"><span class="icon"><i class="fa-solid fa-house"></i></span><span class="lbl">Dashboard Overview</span></a>
      <a href="#" data-target="sec-residents" title="Residents"><span class="icon"><i class="fa-solid fa-users"></i></span><span class="lbl">Residents</span></a>
      <a href="#" data-target="sec-reports" title="Voters Data & Reports"><span class="icon"><i class="fa-solid fa-square-poll-vertical"></i></span><span class="lbl">Voters & Reports</span></a>
      <a href="#" data-target="sec-puroks" title="Purok Management"><span class="icon"><i class="fa-solid fa-house-chimney"></i></span><span class="lbl">Purok Management</span></a>
      <a href="#" data-target="sec-users" title="User Management"><span class="icon"><i class="fa-solid fa-user-gear"></i></span><span class="lbl">User Management</span></a>
      <a href="#" data-target="sec-activity" title="Activity Logs"><span class="icon"><i class="fa-regular fa-clock"></i></span><span class="lbl">Activity Logs</span></a>
      <a href="#" data-target="sec-settings" title="Settings"><span class="icon"><i class="fa-solid fa-gear"></i></span><span class="lbl">Settings</span></a>
    </nav>
    <div class="footer">
      <a href="#" onclick="logout();return false;" title="Logout" class="logout-btn"><span class="icon"><i class="fa-solid fa-right-from-bracket"></i></span><span class="lbl">Logout</span></a>
    </div>
  </aside>

  <div class="content">
    <header>
      <h1>Admin Dashboard</h1>
      <button id="sidebarToggle" title="Collapse sidebar" onclick="document.body.classList.toggle('nav-collapsed')">☰</button>
    </header>

    <main>
      <section class="stats" id="sec-overview" data-section="sec-overview">
        <div class="card">
          <h2>Total Population</h2>
          <p id="totalResidents">—</p>
        </div>
        <div class="card">
          <h2>Households</h2>
          <p id="totalHouseholds">—</p>
        </div>
        <div class="card">
          <h2>Active Users</h2>
          <p id="activeUsers">—</p>
        </div>
        <div class="card">
          <h2>User Administration</h2>
          <p><a href="#" class="btn btn-primary" data-target="sec-users">Manage Users</a></p>
        </div>
      </section>

      <section id="sec-settings" data-section="sec-settings" style="display:none;">
        <div class="card">
          <div class="card-header">
            <h2>Profile Settings</h2>
          </div>
          <div style="display:flex; gap:16px; flex-wrap:wrap;">
            <form id="profileForm" style="flex:1; min-width:280px;">
              <div class="form-group">
                <label>Username</label>
                <input id="set_username" class="form-control" type="text" disabled />
              </div>
              <div class="form-group">
                <label>Full Name</label>
                <input id="set_full_name" class="form-control" type="text" placeholder="Your full name" />
              </div>
              <div class="form-group">
                <label>Role</label>
                <input id="set_role" class="form-control" type="text" disabled />
              </div>
              <div class="form-actions">
                <button type="submit" class="btn btn-primary">Save Profile</button>
              </div>
            </form>

            <form id="passwordForm" style="flex:1; min-width:280px;">
              <div class="form-group">
                <label>Current Password</label>
                <input id="set_current_password" class="form-control" type="password" autocomplete="current-password" />
              </div>
              <div class="form-group">
                <label>New Password</label>
                <input id="set_new_password" class="form-control" type="password" autocomplete="new-password" />
              </div>
              <div class="form-group">
                <label>Confirm New Password</label>
                <input id="set_confirm_password" class="form-control" type="password" autocomplete="new-password" />
              </div>
              <div class="form-actions">
                <button type="submit" class="btn btn-secondary">Change Password</button>
              </div>
            </form>
          </div>
        </div>
      </section>

      <!-- Resident Edit Modal -->
      <div id="residentEditModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.35); align-items:center; justify-content:center;">
        <div style="background:#fff; padding:16px; border-radius:8px; width:min(800px,95vw); max-height:90vh; overflow:auto;">
          <h3>Edit Resident</h3>
          <form>
            <input type="hidden" name="id" />
            <input name="purok_id" placeholder="Purok ID" required />
            <select name="household_id"><option value="">Select Household (optional)</option></select>
            <input name="last_name" placeholder="Last Name" required />
            <input name="first_name" placeholder="First Name" required />
            <input name="middle_name" placeholder="Middle Name (optional)" />
            <input name="full_name" placeholder="Full Name" required readonly />
            <input type="date" name="birth_date" required />
            <input type="number" name="age" placeholder="Age" required />
            <select name="gender" required><option value="">Gender</option><option>Male</option><option>Female</option><option>Other</option></select>
            <select name="civil_status" required>
              <option value="">Civil Status</option>
              <option>Single</option>
              <option>Married</option>
              <option>Widowed</option>
              <option>Separated</option>
            </select>
            <textarea name="address" placeholder="Address" required></textarea>
            <input name="contact_number" placeholder="Contact Number" required />
            <input type="email" name="email" placeholder="Email" required />
            <input name="occupation" placeholder="Occupation" required />
            <input name="educational_attainment" placeholder="Educational Attainment" required />
            <input name="religion" placeholder="Religion" required />
            <input name="citizenship" placeholder="Citizenship" required />
            <input name="blood_type" placeholder="Blood Type" required />
            <textarea name="remarks" placeholder="Remarks" required></textarea>
            <label><input type="checkbox" name="voter_registered" /> Registered Voter</label>
            <input name="voter_status" placeholder="Voter Status" required />
            <div style="display:flex; gap:8px; margin-top:8px;">
              <button type="submit">Save</button>
              <button type="button" data-close>Cancel</button>
            </div>
          </form>
        </div>
      </div>

      <div id="userEditModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.35); align-items:center; justify-content:center;">
        <div style="background:#fff; padding:16px; border-radius:8px; width:min(520px,95vw); max-height:90vh; overflow:auto;">
          <h3>Edit User</h3>
          <form id="userEditForm">
            <input type="hidden" name="id" />
            <div class="form-group">
              <label>Full Name</label>
              <input name="full_name" class="form-control" placeholder="Full Name" />
            </div>
            <div class="form-group">
              <label>Role</label>
              <select name="role" class="form-control" required>
                <option value="admin">Admin</option>
                <option value="staff">Staff</option>
                <option value="purok">Purok</option>
              </select>
            </div>
            <div class="form-group">
              <label>Status</label>
              <select name="status" class="form-control" required>
                <option value="active">Active</option>
                <option value="disabled">Disabled</option>
              </select>
            </div>
            <div class="form-group">
              <label>Purok ID (for Purok role)</label>
              <input name="purok_id" class="form-control" placeholder="Purok ID" />
            </div>
            <div class="form-actions" style="display:flex; gap:8px; margin-top:8px;">
              <button type="submit" class="btn btn-primary">Save</button>
              <button type="button" class="btn btn-secondary" data-user-close>Cancel</button>
            </div>
          </form>
        </div>
      </div>

      <section class="charts" data-section="sec-overview">
        <div class="chart-card"><canvas id="chartGender" height="300"></canvas></div>
        <div class="chart-card"><canvas id="chartPurokPopulation" height="300"></canvas></div>
        <div class="chart-card"><canvas id="chartAge" height="300"></canvas></div>
        <div class="chart-card"><canvas id="chartVoters" height="300"></canvas></div>
        <div class="chart-card"><canvas id="chartOccupation" height="300"></canvas></div>
        <div class="chart-card"><canvas id="chartDaily" height="300"></canvas></div>
      </section>

      <section id="sec-residents" data-section="sec-residents" style="display:none;">
        <div class="card">
          <h2>Add Resident</h2>
          <form class="resident-form">
            <!-- Row 1 -->
            <div class="form-row">
              <div class="form-group">
                <label>Purok ID *</label>
                <input type="text" name="purok_id" required class="form-control" />
              </div>
              <div class="form-group">
                <label>Last Name *</label>
                <input type="text" name="last_name" required class="form-control" />
              </div>
              <div class="form-group">
                <label>First Name *</label>
                <input type="text" name="first_name" required class="form-control" />
              </div>
            </div>

            <!-- Row 2 -->
            <div class="form-row">
              <div class="form-group">
                <label>Middle Name</label>
                <input type="text" name="middle_name" class="form-control" />
              </div>
              <div class="form-group">
                <label>Birth Date *</label>
                <input type="date" name="birth_date" required class="form-control" />
              </div>
              <div class="form-group">
                <label>Age *</label>
                <input type="number" name="age" required class="form-control" readonly />
              </div>
            </div>

            <!-- Row 3 -->
            <div class="form-row">
              <div class="form-group">
                <label>Gender *</label>
                <select name="gender" required class="form-control">
                  <option value="">Select Gender</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
              <div class="form-group">
                <label>Civil Status *</label>
                <select name="civil_status" required class="form-control">
                  <option value="">Select Status</option>
                  <option>Single</option>
                  <option>Married</option>
                  <option>Widowed</option>
                  <option>Separated</option>
                </select>
              </div>
              <div class="form-group">
                <label>Contact Number *</label>
                <input type="tel" name="contact_number" required class="form-control" />
              </div>
            </div>

            <!-- Row 4 -->
            <div class="form-row">
              <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" required class="form-control" />
              </div>
              <div class="form-group">
                <label>Religion *</label>
                <input type="text" name="religion" required class="form-control" />
              </div>
              <div class="form-group">
                <label>Citizenship *</label>
                <input type="text" name="citizenship" required class="form-control" />
              </div>
            </div>

            <!-- Row 5 -->
            <div class="form-row">
              <div class="form-group">
                <label>Blood Type *</label>
                <input type="text" name="blood_type" required class="form-control" />
              </div>
              <div class="form-group">
                <label>Occupation *</label>
                <input type="text" name="occupation" required class="form-control" />
              </div>
              <div class="form-group">
                <label>Educational Attainment *</label>
                <input type="text" name="educational_attainment" required class="form-control" />
              </div>
            </div>

            <!-- Row 6 -->
            <div class="form-row">
              <div class="form-group">
                <label>Voter Status *</label>
                <select name="voter_status" required class="form-control">
                  <option value="">Select Status</option>
                  <option value="Registered">Registered</option>
                  <option value="Not Registered">Not Registered</option>
                </select>
              </div>
              <div class="form-group">
                <label>Household</label>
                <select name="household_id" class="form-control">
                  <option value="">Select Household (optional)</option>
                </select>
              </div>
              <div class="form-group">
                <label>Address *</label>
                <input type="text" name="address" required class="form-control" />
              </div>
            </div>

            <!-- Form Actions -->
            <div class="form-actions">
              <button type="submit" class="btn btn-primary">Add Resident</button>
              <button type="reset" class="btn btn-secondary">Clear Form</button>
            </div>
          </form>
        </div>
        <div class="card" style="margin-top:10px;">
          <h2>Residents</h2>
          <div style="margin-bottom:8px; display:flex; flex-wrap:wrap; gap:10px; align-items:center; justify-content:space-between;">
            <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
              <label>Purok:
                <select id="adminPurokFilter" style="margin-left:4px; padding:4px 8px; border-radius:6px; border:1px solid #d1d5db;">
                  <option value="">All</option>
                </select>
              </label>
              <label>Gender:
                <select id="resFilterGender" style="margin-left:4px; padding:4px 8px; border-radius:6px; border:1px solid #d1d5db;">
                  <option value="">All</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </label>
              <label>Age Group:
                <select id="resFilterAge" style="margin-left:4px; padding:4px 8px; border-radius:6px; border:1px solid #d1d5db;">
                  <option value="">All</option>
                  <option value="0-17">0-17</option>
                  <option value="18-35">18-35</option>
                  <option value="36-59">36-59</option>
                  <option value="60+">60+</option>
                </select>
              </label>
              <label>Voter:
                <select id="purokVoterFilter" style="margin-left:4px; padding:4px 8px; border-radius:6px; border:1px solid #d1d5db;">
                  <option value="">All</option>
                  <option value="registered">Registered</option>
                  <option value="not_registered">Not Registered</option>
                </select>
              </label>
            </div>
          </div>
          <div class="error" style="color:#fca5a5;"></div>
          <div class="table-responsive">
            <table class="residents-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Age</th>
                  <th>Gender</th>
                  <th>Purok</th>
                  <th>Contact</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- Voters & Reports Section -->
      <section id="sec-reports" data-section="sec-reports" style="display:none;">
        <!-- Voter Statistics -->
        <div class="card">
          <h2>Voter Statistics</h2>
          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-icon" style="background-color: #3b82f6;">
                <i class="fas fa-user-check"></i>
              </div>
              <div class="stat-info">
                <h3>Total Voters</h3>
                <p id="totalVoters">—</p>
              </div>
            </div>
            <div class="stat-card">
              <div class="stat-icon" style="background-color: #10b981;">
                <i class="fas fa-male"></i>
              </div>
              <div class="stat-info">
                <h3>Male Voters</h3>
                <p id="maleVoters">—</p>
              </div>
            </div>
            <div class="stat-card">
              <div class="stat-icon" style="background-color: #8b5cf6;">
                <i class="fas fa-female"></i>
              </div>
              <div class="stat-info">
                <h3>Female Voters</h3>
                <p id="femaleVoters">—</p>
              </div>
            </div>
            <div class="stat-card">
              <div class="stat-icon" style="background-color: #ef4444;">
                <i class="fas fa-user-times"></i>
              </div>
              <div class="stat-info">
                <h3>Non-Voters</h3>
                <p id="nonVoters">—</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Voter Distribution by Purok -->
        <div class="card" style="margin-top: 20px;">
          <div class="card-header">
            <h2>Voter Distribution by Purok</h2>
            <div class="card-actions">
              <button class="btn btn-sm btn-primary" id="exportVoterData">
                <i class="fas fa-download"></i> Export Data
              </button>
            </div>
          </div>
          <div class="chart-container">
            <canvas id="voterDistributionChart"></canvas>
          </div>
        </div>

        <!-- Voter Age Distribution -->
        <div class="card" style="margin-top: 20px;">
          <h2>Voter Age Distribution</h2>
          <div class="chart-container">
            <canvas id="voterAgeChart"></canvas>
          </div>
        </div>

        <!-- Voter Registration Report -->
        <div class="card" style="margin-top: 20px;">
          <div class="card-header">
            <h2>Voter Registration Report</h2>
            <div class="form-inline">
              <select id="reportYear" class="form-control">
                <option value="2023">2023</option>
                <option value="2024" selected>2024</option>
                <option value="2025">2025</option>
              </select>
              <button class="btn btn-primary" id="generateReport">Generate</button>
            </div>
          </div>
          <div class="table-responsive">
            <table class="data-table" id="voterReportTable">
              <thead>
                <tr>
                  <th>Month</th>
                  <th>New Voters</th>
                  <th>Male</th>
                  <th>Female</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody id="voterReportBody">
                <!-- Will be populated by JavaScript -->
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section id="sec-users" data-section="sec-users" style="display:none;">
        <div class="card">
          <div class="card-header">
            <h2>User Management</h2>
          </div>
          <div class="form-inline" style="margin:10px 0; display:flex; gap:8px; flex-wrap:wrap; justify-content:center;">
            <form id="userCreateForm" style="max-width: 460px; width: 100%;">
              <input name="username" class="form-control" placeholder="Username" required />
              <input name="full_name" class="form-control" placeholder="Full Name (optional)" />
              <select name="role" class="form-control" required>
                <option value="">Role</option>
                <option value="admin">Admin</option>
                <option value="staff">Staff</option>
                <option value="purok">Purok</option>
              </select>
              <input name="purok_id" class="form-control" placeholder="Purok ID (for Purok role)" />
              <input type="password" name="password" class="form-control" placeholder="Password" required />
              <button type="submit" class="btn btn-primary">Create User</button>
            </form>
          </div>
          <div class="error" style="color:#b91c1c; margin:6px 0;"></div>
          <div class="table-responsive">
            <table class="data-table" id="userTable">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Full Name</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Purok</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="userTableBody"></tbody>
            </table>
          </div>
        </div>
      </section>

      <section id="sec-activity" data-section="sec-activity" style="display:none;">
        <div class="card">
          <div class="card-header">
            <h2>Activity Logs</h2>
          </div>
          <div class="table-responsive">
            <table class="data-table" id="activityTable">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>User</th>
                  <th>Action</th>
                  <th>Entity</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody id="activityTableBody"></tbody>
            </table>
          </div>
        </div>
      </section>

      <section id="sec-reports" data-section="sec-reports" style="display:none;">
        <div class="card">
          <h2>Reports</h2>
          <p>
            <a class="btn" href="../../PHP/export_csv.php" target="_blank">Export CSV (All)</a>
            <a class="btn" href="../../PHP/export_report.php" target="_blank">Printable Report</a>
          </p>
        </div>
      </section>

      <section id="sec-puroks" data-section="sec-puroks" style="display:none;">
        <div class="card">
          <div class="card-header">
            <h2>Purok Management</h2>
            <div class="form-inline">
              <input id="purokNameInput" class="form-control" placeholder="New purok name" />
              <button id="addPurokBtn" class="btn btn-primary">Add Purok</button>
            </div>
          </div>
          <div class="table-responsive">
            <table class="data-table" id="purokTable">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Residents</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="purokTableBody"></tbody>
            </table>
          </div>
        </div>
      </section>
    </main>

    <footer>
      <p> 2025 Barangay Profiling and Management System</p>
    </footer>
  </div>
  <script>
    async function logout(){
      try{ await fetch('../../PHP/logout.php',{method:'POST'}); }catch(e){}
      window.location.href = '../home/home.html';
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <script src="../../JAVASCRIPT/dashboard.js"></script>
  <script src="../../JAVASCRIPT/dashboards_ui.js"></script>
  <script src="../../JAVASCRIPT/user_activity.js?v=2"></script>
  <script src="../../JAVASCRIPT/purok_management.js?v=1"></script>
  <script src="../../JAVASCRIPT/voters.js?v=1"></script>
  <script src="../../JAVASCRIPT/settings.js?v=1"></script>
  <script>
    // populate totals when stats are fetched
    (function(){
      const orig = (window.BrgyDashboard && window.BrgyDashboard.fetchStats) || null;
      if (!orig) return;
      window.BrgyDashboard.fetchStats = async function(params){
        const q = params ? ('?' + new URLSearchParams(params)) : '';
        try{
          const res = await fetch('../../PHP/stats.php' + q, { cache:'no-store' });
          const json = await res.json();
          if (json && json.ok && json.totals){
            const t = json.totals; 
            const el = (id,v)=>{ const n=document.getElementById(id); if(n) n.textContent = v; };
            el('totalResidents', t.residents);
            el('totalHouseholds', t.households);
            el('activeUsers', t.active_users);
          }
          if (window.BrgyDashboard && window.BrgyDashboard.render) window.BrgyDashboard.render(json);
        } catch(e){ /* fallback handled by dashboard.js */ }
      };
    })();
    // initial load
    document.addEventListener('DOMContentLoaded', function(){
      if (window.BrgyDashboard && window.BrgyDashboard.fetchStats) {
        window.BrgyDashboard.fetchStats();
      }
    });
  </script>
</body>
</html>
