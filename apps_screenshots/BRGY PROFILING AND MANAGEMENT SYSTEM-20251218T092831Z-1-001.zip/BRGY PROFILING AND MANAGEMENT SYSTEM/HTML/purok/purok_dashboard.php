<?php
 require_once __DIR__ . '/../../PHP/auth_guard.php';
 require_login(['purok']);
 require_once __DIR__ . '/../../PHP/db_config.php';

 $purokTitle = 'Purok Overview';
 if (!empty($_SESSION['purok_id'])) {
   try {
     $pdo = DB::pdo();
     $stmt = $pdo->prepare('SELECT name FROM puroks WHERE id = :id LIMIT 1');
     $stmt->execute([':id' => $_SESSION['purok_id']]);
     $name = $stmt->fetchColumn();
     if ($name) {
       $purokTitle = $name;
     } else {
       $purokTitle = 'Purok ' . $_SESSION['purok_id'];
     }
   } catch (Throwable $e) {
     $purokTitle = 'Purok Overview';
   }
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Purok Leader Dashboard</title>
  <link rel="stylesheet" href="../../CSS/dashboard_layout.css">
  <link rel="stylesheet" href="../../CSS/purok_dashboard.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
  </head>
<body>
  <aside class="sidebar">
    <div class="brand">
      <img src="../../assets/images/logo.png" alt="Logo" />
      <h1>Barangay Profiling</h1>
    </div>
    <nav class="nav" aria-label="Purok Navigation">
      <a href="#" class="active" data-target="sec-overview" title="Dashboard Overview"><span class="icon"><i class="fa-solid fa-house"></i></span><span class="lbl">Dashboard Overview</span></a>
      <a href="#" data-target="sec-residents" title="Residents"><span class="icon"><i class="fa-solid fa-users"></i></span><span class="lbl">Residents</span></a>
      <a href="#" data-target="sec-households" title="Households"><span class="icon"><i class="fa-solid fa-house"></i></span><span class="lbl">Households</span></a>
      <a href="#" data-target="sec-residents" data-voters-nav="1" title="Voters Status"><span class="icon"><i class="fa-solid fa-square-poll-vertical"></i></span><span class="lbl">Voters Status</span></a>
      <a href="#" data-target="sec-stats" title="Statistics"><span class="icon"><i class="fa-solid fa-chart-column"></i></span><span class="lbl">Statistics</span></a>
      <a href="#" data-target="sec-profile" title="Profile Settings"><span class="icon"><i class="fa-solid fa-user"></i></span><span class="lbl">Profile Settings</span></a>
    </nav>
    <div class="footer">
      <a href="#" onclick="logout();return false;" title="Logout"><span class="icon"><i class="fa-solid fa-right-from-bracket"></i></span><span class="lbl">Logout</span></a>
    </div>
  </aside>

  <div class="content">
    <header>
      <h1><?php echo htmlspecialchars($purokTitle, ENT_QUOTES, 'UTF-8'); ?></h1>
      <button id="sidebarToggle" title="Collapse sidebar" onclick="document.body.classList.toggle('nav-collapsed')">☰</button>
    </header>

    <main>
      <div class="summary" id="sec-overview" data-section="sec-overview">
        <div class="card">Total Residents: <span id="totalResidents">—</span></div>
        <div class="card">Households: <span id="totalHouseholds">—</span></div>
      </div>

      <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:8px 0;">
        <button id="detailsToggle" onclick="var p=document.getElementById('detailsPanel'); if(p) p.style.display = (p.style.display==='none'||!p.style.display)?'grid':'none';">More Details</button>
        <a class="btn" href="../../PHP/export_csv.php" target="_blank">Export CSV</a>
        <a class="btn" href="../../PHP/export_report.php" target="_blank">Printable Report</a>
      </div>

      <div id="detailsPanel" style="display:none;" data-section="sec-overview">
        <div class="card">Male: <span id="totalMale">—</span></div>
        <div class="card">Female: <span id="totalFemale">—</span></div>
        <div class="card">Other: <span id="totalOther">—</span></div>
        <div class="card">0-17: <span id="count0_17">—</span></div>
        <div class="card">18-35: <span id="count18_35">—</span></div>
        <div class="card">36-59: <span id="count36_59">—</span></div>
        <div class="card">60+: <span id="count60p">—</span></div>
        <div class="card">Voters Registered: <span id="votersRegistered">—</span></div>
        <div class="card">Not Registered: <span id="votersNotRegistered">—</span></div>
        <div class="card">Household Occupancy: <span id="householdOccupancy">—</span></div>
      </div>
      <section class="charts" id="sec-stats" data-section="sec-stats" style="display:none;">
        <div class="chart-card">
          <h3>Gender Distribution</h3>
          <canvas id="chartGender" height="140"></canvas>
        </div>
        <div class="chart-card">
          <h3>Age Group Distribution</h3>
          <canvas id="chartAge" height="140"></canvas>
        </div>
        <div class="chart-card">
          <h3>Voter Registration Status</h3>
          <canvas id="chartVoters" height="140"></canvas>
        </div>
      </section>

      <section id="sec-residents" data-section="sec-residents" style="display:none;">
        <div class="card" data-add-resident-card="1" style="display:none;">
          <h2>Add Resident</h2>
          <form>
            <!-- purok_id omitted; backend scopes to current purok; households list will auto-scope -->
            <select name="household_id"><option value="">Select Household (optional)</option></select>
            <input name="last_name" placeholder="Last Name" required />
            <input name="first_name" placeholder="First Name" required />
            <input name="middle_name" placeholder="Middle Name (optional)" />
            <input name="full_name" placeholder="Full Name (auto if names provided)" required readonly />
            <input type="date" name="birth_date" required />
            <input type="number" name="age" placeholder="Age (auto)" required />
            <select name="gender" required><option value="">Gender</option><option>Male</option><option>Female</option><option>Other</option></select>
            <select name="civil_status" required>
              <option value="">Civil Status</option>
              <option>Single</option>
              <option>Married</option>
              <option>Widowed</option>
              <option>Separated</option>
            </select>
            <input name="address" placeholder="Address" required />
            <input name="contact_number" placeholder="Contact Number" required />
            <input type="email" name="email" placeholder="Email" required />
            <input name="occupation" placeholder="Occupation" required />
            <input name="educational_attainment" placeholder="Educational Attainment" required />
            <input name="religion" placeholder="Religion" required />
            <input name="citizenship" placeholder="Citizenship" required />
            <input name="blood_type" placeholder="Blood Type" required />
            <select name="voter_status" required>
              <option value="">Voter Status</option>
              <option value="Registered">Registered</option>
              <option value="Not Registered">Not Registered</option>
            </select>
            <button type="submit">Add</button>
          </form>
        </div>
        <div class="card" style="margin-top:10px;">
          <h2 id="purokResidentsHeading">Residents</h2>
          <div class="error" style="color:#fca5a5;"></div>
          <div style="margin-bottom:8px; display:flex; flex-wrap:wrap; gap:10px; align-items:center; justify-content:space-between;">
            <button id="btnAddResident" type="button" style="padding:8px 12px; border-radius:8px; border:1px solid #2563eb; background:#2563eb; color:#fff; font-weight:600; cursor:pointer;">+ Add Resident</button>
            <div style="display:flex; flex-wrap:wrap; gap:8px; font-size:0.85rem; color:#4b5563;">
              <label>Gender:
                <select id="resFilterGender" style="margin-left:4px; padding:4px 8px; border-radius:6px; border:1px solid #d1d5db;">
                  <option value="">All</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </label>
              <label>Age Group:
                <select id="resFilterAge" style="margin-left:4px; padding:4px 8px; border-radius:6px; border:1px solid #d1d5db;">
                  <option value="">All</option>
                  <option value="0-17">Kids (0-17)</option>
                  <option value="18-35">Teens (18-35)</option>
                  <option value="36-59">Adult (36-59)</option>
                  <option value="60+">Senior (60+)</option>
                </select>
              </label>
              <label>Voter:
                <select id="purokVoterFilter" style="margin-left:4px; padding:4px 8px; border-radius:6px; border:1px solid #d1d5db;">
                  <option value="">All</option>
                  <option value="registered">Registered</option>
                  <option value="not_registered">Not Registered</option>
                </select>
              </label>
            </div>
          </div>
          <div id="purokVotersChartWrap" style="display:none; margin-bottom:10px;">
            <h3 style="margin:0 0 6px; font-weight:600;">Voter Registration Status (This Purok)</h3>
            <div class="chart-card" style="padding:8px;">
              <canvas id="chartVotersPurok" height="120"></canvas>
            </div>
          </div>
          <table width="100%"><thead><tr><th>ID</th><th>Name</th><th>Age</th><th>Gender</th><th>Purok</th><th>Contact</th><th>Voter Registered</th><th>Voter Status</th><th>Actions</th></tr></thead><tbody></tbody></table>
        </div>
      </section>

      <section id="sec-profile" data-section="sec-profile" style="display:none;">
        <div class="card">
          <h2>Profile Settings</h2>
          <div class="error" style="color:#fca5a5;"></div>
          <form id="form-profile">
            <input name="full_name" placeholder="Full Name" required />
            <button type="button" style="display:none;">Save Profile</button>
          </form>
        </div>
        <div class="card" style="margin-top:10px;">
          <h2>Change Password</h2>
          <form id="form-password">
            <input type="password" name="current_password" placeholder="Current Password" required />
            <input type="password" name="new_password" placeholder="New Password" required />
            <button type="button" style="display:none;">Change Password</button>
          </form>
        </div>
        <div class="card" style="margin-top:10px;">
          <h2>Profile Photo</h2>
          <div style="display:flex; gap:16px; align-items:center; justify-content:center; flex-wrap:wrap;">
            <img id="profPhoto" src="" alt="Profile Photo" style="width:96px;height:96px;border-radius:50%;object-fit:cover;border:1px solid #e5e7eb;background:#f9fafb;" />
            <form id="form-photo" enctype="multipart/form-data">
              <input type="file" name="photo" accept="image/png,image/jpeg" required />
              <button type="button" style="display:none;">Upload</button>
            </form>
          </div>
        </div>
        <div style="max-width:960px;margin:8px auto 0;text-align:right;">
          <button id="btnProfileUpdateAll" type="button">Update Profile</button>
        </div>
      </section>

      <!-- Resident Edit Modal -->
      <div id="residentEditModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.35); align-items:center; justify-content:center;">
        <div style="background:#fff; padding:16px; border-radius:8px; width:min(800px,95vw); max-height:90vh; overflow:auto;">
          <h3>Edit Resident</h3>
          <form>
            <input type="hidden" name="id" />
            <!-- purok_id omitted; backend scopes -->
            <select name="household_id"><option value="">Select Household (optional)</option></select>
            <input name="last_name" placeholder="Last Name" required />
            <input name="first_name" placeholder="First Name" required />
            <input name="middle_name" placeholder="Middle Name (optional)" />
            <input name="full_name" placeholder="Full Name" required />
            <input type="date" name="birth_date" required />
            <input type="number" name="age" placeholder="Age" required />
            <select name="gender" required><option value="">Gender</option><option>Male</option><option>Female</option><option>Other</option></select>
            <select name="civil_status" required>
              <option value="">Civil Status</option>
              <option>Single</option>
              <option>Married</option>
              <option>Widowed</option>
              <option>Separated</option>
            </select>
            <textarea name="address" placeholder="Address" required></textarea>
            <input name="contact_number" placeholder="Contact Number" required />
            <input type="email" name="email" placeholder="Email" required />
            <input name="occupation" placeholder="Occupation" required />
            <input name="educational_attainment" placeholder="Educational Attainment" required />
            <input name="religion" placeholder="Religion" required />
            <input name="citizenship" placeholder="Citizenship" required />
            <input name="blood_type" placeholder="Blood Type" required />
            <select name="voter_status" required>
              <option value="">Voter Status</option>
              <option value="Registered">Registered</option>
              <option value="Not Registered">Not Registered</option>
            </select>
            <div style="display:flex; gap:8px; margin-top:8px;">
              <button type="submit">Save</button>
              <button type="button" data-close>Cancel</button>
            </div>
          </form>
        </div>
      </div>

      <section id="sec-households" data-section="sec-households" style="display:none;">
        <div class="card">
          <h2>Add Household</h2>
          <form>
            <input name="household_head_name" placeholder="Household Head Name" />
            <input name="address" placeholder="Address" />
            <button type="submit">Add</button>
          </form>
        </div>
        <div class="card" style="margin-top:10px;">
          <h2>Households (Your Purok)</h2>
          <div class="error" style="color:#fca5a5;"></div>
          <table width="100%"><thead><tr><th>ID</th><th>Head</th><th>Address</th><th>Actions</th></tr></thead><tbody></tbody></table>
        </div>
      </section>
    </main>
  </div>

  <script>
    async function logout(){
      try{ await fetch('../../PHP/logout.php',{method:'POST'}); }catch(e){}
      window.location.href = '../home/home.html';
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
  <script src="../../JAVASCRIPT/dashboard.js"></script>
  <script src="../../JAVASCRIPT/dashboards_ui.js"></script>
  <script>
    // On purok scope, stats.php will auto-filter by session purok_id
    (function(){
      const orig = (window.BrgyDashboard && window.BrgyDashboard.fetchStats) || null;
      if (!orig) return;
      window.BrgyDashboard.fetchStats();
      // also populate summary cards
      fetch('../../PHP/stats.php', { cache: 'no-store' }).then(r=>r.json()).then(json=>{
        if (json && json.ok && json.totals){
          const t=json.totals; 
          const el=(id,v)=>{ const n=document.getElementById(id); if(n) n.textContent=v; };
          el('totalResidents', t.residents);
          el('totalHouseholds', t.households);
        }
      }).catch(()=>{});
    })();
  </script>
</body>
</html>
