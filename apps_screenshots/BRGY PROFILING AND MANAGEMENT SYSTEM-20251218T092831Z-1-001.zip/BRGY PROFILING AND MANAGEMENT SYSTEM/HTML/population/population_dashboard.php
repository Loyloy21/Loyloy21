<?php require_once __DIR__ . '/../../PHP/auth_guard.php'; require_login(['admin','staff']); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Staff Dashboard | Population & Reports</title>
  <link rel="stylesheet" href="../../CSS/dashboard_layout.css">
  <link rel="stylesheet" href="../../CSS/population_dashboard.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <aside class="sidebar">
    <div class="brand">
      <img src="../../assets/images/logo.png" alt="Logo" />
      <h1>Barangay Profiling</h1>
    </div>
    <nav class="nav" aria-label="Staff Navigation">
      <a href="#" class="active" data-target="sec-overview" title="Dashboard Overview"><span class="icon"><i class="fa-solid fa-house"></i></span><span class="lbl">Dashboard Overview</span></a>
      <a href="#" data-target="sec-reports" title="Reports"><span class="icon"><i class="fa-solid fa-chart-column"></i></span><span class="lbl">Reports</span></a>
      <a href="#" data-target="sec-activity" title="Recent Updates"><span class="icon"><i class="fa-regular fa-clock"></i></span><span class="lbl">Recent Updates</span></a>
      <a href="#" data-target="sec-profile" title="Profile Settings"><span class="icon"><i class="fa-solid fa-user"></i></span><span class="lbl">Profile Settings</span></a>
    </nav>
    <div class="footer">
      <a href="#" onclick="logout();return false;" title="Logout"><span class="icon"><i class="fa-solid fa-right-from-bracket"></i></span><span class="lbl">Logout</span></a>
    </div>
  </aside>

  <div class="content">
    <header>
      <h1>Staff Dashboard</h1>
      <button id="sidebarToggle" title="Collapse sidebar" onclick="document.body.classList.toggle('nav-collapsed')">☰</button>
    </header>

    <main>
      <div class="summary" id="summary-cards" data-section="sec-overview">
        <div class="card">Total Residents: <span id="totalResidents">—</span></div>
        <div class="card">Households: <span id="totalHouseholds">—</span></div>
        <div class="card">Active Users: <span id="activeUsers">—</span></div>
      </div>
      <div class="filters" id="sec-overview" data-section="sec-overview">
        <select id="purokFilter">
          <option value="">All Puroks</option>
        </select>
        <select id="genderFilter">
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
        <select id="ageFilter">
          <option value="">All Ages</option>
          <option value="0-17">0-17</option>
          <option value="18-35">18-35</option>
          <option value="36-59">36-59</option>
          <option value="60+">60+</option>
        </select>
        <select id="voterFilter">
          <option value="">All Voter Status</option>
          <option value="registered">Registered</option>
          <option value="not_registered">Not Registered</option>
        </select>
        <button id="exportBtn">Export CSV</button>
        <button id="clearFilters">Clear Filters</button>
      </div>

      <section class="charts" data-section="sec-overview">
        <div class="chart-card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
            <h3>Population by Purok</h3>
            <button class="dlChart" data-target="chartPurokPopulation">Download</button>
          </div>
          <canvas id="chartPurokPopulation" height="200" aria-label="Population by Purok" role="img"></canvas>
        </div>
        <div class="chart-card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
            <h3>Gender Distribution</h3>
            <button class="dlChart" data-target="chartGender">Download</button>
          </div>
          <canvas id="chartGender" height="200" aria-label="Gender Distribution" role="img"></canvas>
        </div>
        <div class="chart-card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
            <h3>Age Groups</h3>
            <button class="dlChart" data-target="chartAge">Download</button>
          </div>
          <canvas id="chartAge" height="200" aria-label="Age Groups" role="img"></canvas>
        </div>
        <div class="chart-card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
            <h3>Voter Registration</h3>
            <button class="dlChart" data-target="chartVoters">Download</button>
          </div>
          <canvas id="chartVoters" height="200" aria-label="Voter Registration" role="img"></canvas>
        </div>
        <div class="chart-card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
            <h3>Top Occupations</h3>
            <button class="dlChart" data-target="chartOccupation">Download</button>
          </div>
          <canvas id="chartOccupation" height="200" aria-label="Top Occupations" role="img"></canvas>
        </div>
        <div class="chart-card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
            <h3>Daily Added (7 days)</h3>
            <button class="dlChart" data-target="chartDaily">Download</button>
          </div>
          <canvas id="chartDaily" height="200" aria-label="Daily Added Residents (last 7 days)" role="img"></canvas>
        </div>
      </section>

      

      <section id="sec-activity" data-section="sec-activity" style="display:none;">
        <div class="card">
          <h2>Recent Updates</h2>
          <div style="display:flex; gap:8px; flex-wrap:wrap; margin:8px 0;">
            <input type="date" id="actStart" />
            <input type="date" id="actEnd" />
            <input type="text" id="actUser" placeholder="User" />
            <select id="actAction">
              <option value="">All Actions</option>
              <option value="create">Create</option>
              <option value="update">Update</option>
              <option value="delete">Delete</option>
            </select>
            <button id="actFilterBtn">Apply</button>
            <button id="actClearBtn">Clear</button>
          </div>
          <div class="error" style="color:#fca5a5;"></div>
          <table width="100%"><thead><tr><th>Time</th><th>User</th><th>Role</th><th>Action</th><th>Entity ID</th></tr></thead><tbody></tbody></table>
        </div>
      </section>

      <section id="sec-reports" data-section="sec-reports" style="display:none;">
        <div class="card">
          <h2>Reports</h2>
          <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
            <div>
              <div style="font-weight:600;">CSV Columns</div>
              <label><input type="checkbox" class="colPick" value="id" checked /> ID</label>
              <label><input type="checkbox" class="colPick" value="purok_id" checked /> Purok ID</label>
              <label><input type="checkbox" class="colPick" value="purok_name" checked /> Purok Name</label>
              <label><input type="checkbox" class="colPick" value="gender" checked /> Gender</label>
              <label><input type="checkbox" class="colPick" value="age" checked /> Age</label>
              <label><input type="checkbox" class="colPick" value="birth_date" /> Birth Date</label>
              <label><input type="checkbox" class="colPick" value="occupation" /> Occupation</label>
              <label><input type="checkbox" class="colPick" value="voter_registered" /> Voter Registered</label>
              <label><input type="checkbox" class="colPick" value="voter_status" /> Voter Status</label>
              <label><input type="checkbox" class="colPick" value="created_at" /> Created At</label>
            </div>
            <p>
              <a class="btn" id="csvLink" href="../../PHP/export_csv.php" target="_blank">Export CSV</a>
              <a class="btn" id="printLink" href="../../PHP/export_report.php" target="_blank">Printable Report</a>
            </p>
          </div>
        </div>
      </section>

      <section id="sec-profile" data-section="sec-profile" style="display:none;">
        <div class="card">
          <h2>Profile Settings</h2>
          <div class="error" style="color:#fca5a5;"></div>
          <form id="form-profile">
            <input name="full_name" placeholder="Full Name" required />
            <button type="button" style="display:none;">Save Profile</button>
          </form>
        </div>
        <div class="card" style="margin-top:10px;">
          <h2>Change Password</h2>
          <form id="form-password">
            <input type="password" name="current_password" placeholder="Current Password" required />
            <input type="password" name="new_password" placeholder="New Password" required />
            <button type="button" style="display:none;">Change Password</button>
          </form>
        </div>
        <div class="card" style="margin-top:10px;">
          <h2>Profile Photo</h2>
          <div style="display:flex; gap:16px; align-items:center; justify-content:center; flex-wrap:wrap;">
            <img id="profPhoto" src="" alt="Profile Photo" style="width:96px;height:96px;border-radius:50%;object-fit:cover;border:1px solid #e5e7eb;background:#f9fafb;" />
            <form id="form-photo" enctype="multipart/form-data">
              <input type="file" name="photo" accept="image/png,image/jpeg" required />
              <button type="button" style="display:none;">Upload</button>
            </form>
          </div>
        </div>
        <div style="max-width:960px;margin:8px auto 0;text-align:right;">
          <button id="btnProfileUpdateAll" type="button">Update Profile</button>
        </div>
      </section>
    </main>

  </div>

  <script>
    async function logout(){
      try{ await fetch('../../PHP/logout.php',{method:'POST'}); }catch(e){}
      window.location.href = '../home/home.html';
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <script src="../../JAVASCRIPT/dashboard.js"></script>
  <script src="../../JAVASCRIPT/analytics.js"></script>
  <script src="../../JAVASCRIPT/dashboards_ui.js?v=2"></script>
  <script>
    // Auto-refresh every 60 seconds
    setInterval(()=>{
      if (window.BrgyDashboard && window.BrgyDashboard.fetchStats) {
        const params = window.__currentFilters || {};
        window.BrgyDashboard.fetchStats(params);
      }
    }, 60000);
  </script>
</body>
</html>
