-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2025 at 12:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brgy_profiling`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(64) DEFAULT NULL,
  `role` varchar(32) DEFAULT NULL,
  `action_type` varchar(32) NOT NULL,
  `entity` varchar(32) NOT NULL,
  `entity_id` varchar(64) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `purok_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_sessions`
--

CREATE TABLE `auth_sessions` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `session_token` char(64) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `barangays`
--

CREATE TABLE `barangays` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `name` varchar(150) NOT NULL,
  `city` varchar(150) DEFAULT NULL,
  `province` varchar(150) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `households`
--

CREATE TABLE `households` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `purok_id` char(36) NOT NULL,
  `household_no` varchar(50) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `head_resident_id` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `population_stats`
--

CREATE TABLE `population_stats` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `period` date NOT NULL,
  `metric` varchar(100) NOT NULL,
  `value` int(11) NOT NULL,
  `purok_id` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `puroks`
--

CREATE TABLE `puroks` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `barangay_id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_definitions`
--

CREATE TABLE `report_definitions` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `code` varchar(64) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_by` char(36) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `residents`
--

CREATE TABLE `residents` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `purok_id` char(36) NOT NULL,
  `household_id` char(36) DEFAULT NULL,
  `full_name` varchar(180) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `occupation` varchar(120) DEFAULT NULL,
  `civil_status` enum('Single','Married','Widowed','Separated','Unknown') DEFAULT 'Unknown',
  `address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `educational_attainment` varchar(150) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `citizenship` varchar(100) DEFAULT NULL,
  `blood_type` varchar(10) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `residency_status` enum('Active','Inactive','Migrated','Deceased') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `voter_registered` enum('Yes','No') DEFAULT NULL,
  `voter_status` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `resident_voter_registrations`
--

CREATE TABLE `resident_voter_registrations` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `resident_id` char(36) NOT NULL,
  `is_registered` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(50) NOT NULL DEFAULT 'Not Registered',
  `voter_id_number` varchar(64) DEFAULT NULL,
  `precinct_no` varchar(64) DEFAULT NULL,
  `registration_date` date DEFAULT NULL,
  `last_verified_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `username` varchar(80) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','staff','purok') NOT NULL DEFAULT 'staff',
  `status` enum('active','disabled') NOT NULL DEFAULT 'active',
  `full_name` varchar(255) DEFAULT NULL,
  `purok_id` char(36) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `status`, `full_name`, `purok_id`, `created_at`) VALUES
('6e3a8782-c212-11f0-90c6-089798cfa5b4', 'purok1', '$2y$10$sHGhUrwzXLe/AFNmRU3TIOoAOyeZJC03VSWuws6fBxgYr3SE2MpEW', 'purok', 'active', 'Purok1', '6e3a8782-c212-11f0-90c6-089798cfa5b4', '2025-11-15 11:01:26'),
('79a82f38-c211-11f0-90c6-089798cfa5b4', 'admin', '$2y$10$1u8DByp.6dBjXSCdwMBSk..Br2qlq64jvlOq9JqcoTdgZ91Y7b2wi', 'admin', 'active', 'Admin', NULL, '2025-11-15 10:54:35'),
('a55dc9cf-c211-11f0-90c6-089798cfa5b4', 'staff', '$2y$10$A.DMUyaRJaIY5ScNqmcsBOh8Aux7V61AYHuUOn/xDfBIUOACmLw2K', 'staff', 'active', 'Staff', NULL, '2025-11-15 10:55:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_logs_created` (`created_at`),
  ADD KEY `idx_logs_purok` (`purok_id`);

--
-- Indexes for table `auth_sessions`
--
ALTER TABLE `auth_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `session_token` (`session_token`),
  ADD KEY `idx_sessions_user` (`user_id`),
  ADD KEY `idx_sessions_expires` (`expires_at`);

--
-- Indexes for table `barangays`
--
ALTER TABLE `barangays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `households`
--
ALTER TABLE `households`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_household_per_purok` (`purok_id`,`household_no`),
  ADD KEY `idx_households_purok` (`purok_id`),
  ADD KEY `fk_household_head` (`head_resident_id`);

--
-- Indexes for table `population_stats`
--
ALTER TABLE `population_stats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_metric_period_purok` (`metric`,`period`,`purok_id`),
  ADD KEY `fk_stats_purok` (`purok_id`),
  ADD KEY `idx_stats_period` (`period`);

--
-- Indexes for table `puroks`
--
ALTER TABLE `puroks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_purok_barangay` (`barangay_id`),
  ADD KEY `idx_puroks_name` (`name`);

--
-- Indexes for table `report_definitions`
--
ALTER TABLE `report_definitions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `fk_reportdef_user` (`created_by`);

--
-- Indexes for table `residents`
--
ALTER TABLE `residents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_residents_purok` (`purok_id`),
  ADD KEY `idx_residents_household` (`household_id`),
  ADD KEY `idx_residents_gender` (`gender`),
  ADD KEY `idx_residents_birth` (`birth_date`),
  ADD KEY `idx_residents_voter` (`voter_registered`,`voter_status`);

--
-- Indexes for table `resident_voter_registrations`
--
ALTER TABLE `resident_voter_registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `resident_id` (`resident_id`),
  ADD KEY `idx_voter_status` (`status`),
  ADD KEY `idx_voter_registered` (`is_registered`),
  ADD KEY `idx_voter_precinct` (`precinct_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_status` (`status`),
  ADD KEY `fk_users_purok` (`purok_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_sessions`
--
ALTER TABLE `auth_sessions`
  ADD CONSTRAINT `fk_session_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `households`
--
ALTER TABLE `households`
  ADD CONSTRAINT `fk_household_head` FOREIGN KEY (`head_resident_id`) REFERENCES `residents` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_household_purok` FOREIGN KEY (`purok_id`) REFERENCES `puroks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `population_stats`
--
ALTER TABLE `population_stats`
  ADD CONSTRAINT `fk_stats_purok` FOREIGN KEY (`purok_id`) REFERENCES `puroks` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `puroks`
--
ALTER TABLE `puroks`
  ADD CONSTRAINT `fk_purok_barangay` FOREIGN KEY (`barangay_id`) REFERENCES `barangays` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `report_definitions`
--
ALTER TABLE `report_definitions`
  ADD CONSTRAINT `fk_reportdef_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `residents`
--
ALTER TABLE `residents`
  ADD CONSTRAINT `fk_resident_household` FOREIGN KEY (`household_id`) REFERENCES `households` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_resident_purok` FOREIGN KEY (`purok_id`) REFERENCES `puroks` (`id`);

--
-- Constraints for table `resident_voter_registrations`
--
ALTER TABLE `resident_voter_registrations`
  ADD CONSTRAINT `fk_voter_resident` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_user_purok` FOREIGN KEY (`purok_id`) REFERENCES `puroks` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_users_purok` FOREIGN KEY (`purok_id`) REFERENCES `puroks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
