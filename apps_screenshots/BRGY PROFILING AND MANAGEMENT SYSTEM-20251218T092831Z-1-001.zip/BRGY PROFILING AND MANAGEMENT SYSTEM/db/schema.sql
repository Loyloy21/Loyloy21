-- Barangay Profiling and Management System Schema
-- MySQL 8+

CREATE DATABASE IF NOT EXISTS brgy_profiling CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE brgy_profiling;

CREATE TABLE IF NOT EXISTS barangays (
  id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
  name VARCHAR(150) NOT NULL,
  city VARCHAR(150) NULL,
  province VARCHAR(150) NULL,
  zip_code VARCHAR(10) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS puroks (
  id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
  barangay_id CHAR(36) NOT NULL,
  name VARCHAR(100) NOT NULL,
  CONSTRAINT fk_purok_barangay FOREIGN KEY (barangay_id) REFERENCES barangays(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS households (
  id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
  purok_id CHAR(36) NOT NULL,
  household_no VARCHAR(50) NOT NULL,
  address VARCHAR(255) NULL,
  CONSTRAINT fk_household_purok FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS residents (
  id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
  purok_id CHAR(36) NOT NULL,
  household_id CHAR(36) NULL,
  full_name VARCHAR(180) NOT NULL,
  birth_date DATE NULL,
  gender ENUM('Male','Female','Other') NULL,
  age TINYINT NULL,
  group_name VARCHAR(80) NULL,
  civil_status ENUM('Single','Married','Widowed','Separated','Unknown') DEFAULT 'Unknown',
  residency_status ENUM('Active','Inactive','Migrated','Deceased') DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_residents_purok (purok_id),
  INDEX idx_residents_household (household_id),
  CONSTRAINT fk_resident_purok FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE RESTRICT,
  CONSTRAINT fk_resident_household FOREIGN KEY (household_id) REFERENCES households(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS users (
  id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','staff','purok_leader') NOT NULL DEFAULT 'staff',
  status ENUM('active','disabled') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Optional: short-lived sessions for login management and security
CREATE TABLE IF NOT EXISTS auth_sessions (
  id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
  user_id CHAR(36) NOT NULL,
  session_token CHAR(64) NOT NULL UNIQUE,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NULL,
  CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_sessions_user (user_id),
  INDEX idx_sessions_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS population_stats (
  id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
  period DATE NOT NULL,
  metric VARCHAR(100) NOT NULL,
  value INT NOT NULL,
  purok_id CHAR(36) NULL,
  CONSTRAINT fk_stats_purok FOREIGN KEY (purok_id) REFERENCES puroks(id) ON DELETE SET NULL,
  UNIQUE KEY uq_metric_period_purok (metric, period, purok_id)
);
