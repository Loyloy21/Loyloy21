<?php
require_once __DIR__ . '/db_config.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
header('Content-Type: application/json');
header('Cache-Control: no-store');
@ini_set('display_errors','0');

if (empty($_SESSION['logged_in']) || (($_SESSION['role'] ?? '') !== 'admin')) {
  http_response_code(403);
  echo json_encode(['ok'=>false,'error'=>'Forbidden']);
  exit;
}

function body_json(): array {
  $raw = file_get_contents('php://input');
  if ($raw) { $d = json_decode($raw, true); if (is_array($d)) return $d; }
  return $_POST ?: [];
}

try {
  $pdo = DB::pdo();
  $method = $_SERVER['REQUEST_METHOD'];
  $action = $_GET['action'] ?? $_POST['action'] ?? null;

  if ($method === 'GET' && (!$action || $action === 'list')) {
    $stmt = $pdo->query("SELECT p.id, p.name,
              (SELECT COUNT(*) FROM residents r WHERE r.purok_id = p.id) AS resident_count
            FROM puroks p ORDER BY p.name");
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) { if (!isset($r['created_at'])) $r['created_at'] = null; }
    echo json_encode(['ok'=>true,'data'=>$rows]);
    exit;
  }

  if ($method === 'POST' && $action === 'create') {
    $in = body_json();
    $name = trim($in['name'] ?? '');
    if ($name === '') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'name required']); exit; }

    // Find a barangay_id to attach; create one if none exists
    $bid = $pdo->query("SELECT id FROM barangays LIMIT 1")->fetchColumn();
    if (!$bid) {
      $pdo->exec("INSERT INTO barangays (id, name) VALUES (uuid(), 'Barangay')");
      $bid = $pdo->query("SELECT id FROM barangays LIMIT 1")->fetchColumn();
    }

    $stmt = $pdo->prepare("INSERT INTO puroks (barangay_id, name) VALUES (:bid, :name)");
    $stmt->execute([':bid'=>$bid, ':name'=>$name]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  if ($method === 'POST' && $action === 'rename') {
    $in = body_json();
    $id = (string)($in['id'] ?? '');
    $name = trim($in['name'] ?? '');
    if ($id === '' || $name === '') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id and name required']); exit; }
    $stmt = $pdo->prepare("UPDATE puroks SET name = :n WHERE id = :id");
    $stmt->execute([':n'=>$name, ':id'=>$id]);
    echo json_encode(['ok'=>true,'updated'=>$stmt->rowCount()]);
    exit;
  }

  if ($method === 'POST' && $action === 'delete') {
    $in = body_json();
    $id = (string)($in['id'] ?? '');
    if ($id === '') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required']); exit; }

    $cnt = $pdo->prepare('SELECT COUNT(*) FROM residents WHERE purok_id = :id');
    $cnt->execute([':id'=>$id]);
    if ((int)$cnt->fetchColumn() > 0) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Cannot delete purok with residents']); exit; }

    $pdo->prepare('DELETE FROM puroks WHERE id = :id')->execute([':id'=>$id]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'Unsupported action']);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
