<?php
require_once __DIR__ . '/db_config.php';
session_start();
header('Content-Type: application/json');
header('Cache-Control: no-store');
@ini_set('display_errors','0');

try {
  $pdo = DB::pdo();
  $purokId = isset($_GET['purok_id']) && $_GET['purok_id'] !== '' ? $_GET['purok_id'] : null;
  // If logged-in role is purok, force filter to their assigned purok_id
  if (isset($_SESSION['role']) && $_SESSION['role'] === 'purok' && !empty($_SESSION['purok_id'])) {
    $purokId = $_SESSION['purok_id'];
  }
  // Filters
  $gendersCsv = isset($_GET['genders']) && $_GET['genders'] !== '' ? $_GET['genders'] : null; // comma separated
  $genders = $gendersCsv ? array_values(array_filter(array_map('trim', explode(',', $gendersCsv)))) : [];
  $gender = isset($_GET['gender']) && $_GET['gender'] !== '' ? $_GET['gender'] : null; // back-compat single gender
  if ($gender && empty($genders)) { $genders = [$gender]; }
  $ageBucket = isset($_GET['age_bucket']) && $_GET['age_bucket'] !== '' ? $_GET['age_bucket'] : null; // '0-17','18-35','36-59','60+'
  $ageMin = isset($_GET['age_min']) && $_GET['age_min'] !== '' ? max(0, (int)$_GET['age_min']) : null;
  $ageMax = isset($_GET['age_max']) && $_GET['age_max'] !== '' ? max(0, (int)$_GET['age_max']) : null;
  $voter = isset($_GET['voter']) && $_GET['voter'] !== '' ? strtolower($_GET['voter']) : null; // 'registered'|'not_registered'
  $voterOnly = isset($_GET['voter_only']) && $_GET['voter_only'] !== '' ? (int)!!$_GET['voter_only'] : 0;
  $startDate = isset($_GET['start_date']) && $_GET['start_date'] !== '' ? $_GET['start_date'] : null; // YYYY-MM-DD
  $endDate = isset($_GET['end_date']) && $_GET['end_date'] !== '' ? $_GET['end_date'] : null;

  $filterSql = ' WHERE 1=1 ';
  $params = [];
  if ($purokId) { $filterSql .= ' AND r.purok_id = :purok_id '; $params[':purok_id'] = $purokId; }
  if (!empty($genders)) {
    $in = [];
    foreach ($genders as $idx=>$g) { $ph = ":g$idx"; $in[] = $ph; $params[$ph] = $g; }
    $filterSql .= ' AND COALESCE(r.gender,\'Other\') IN (' . implode(',', $in) . ') ';
  }
  // back-compat single
  if ($gender && empty($genders)) { $filterSql .= ' AND COALESCE(r.gender,\'Other\') = :gender '; $params[':gender'] = $gender; }
  if ($voter === 'registered') {
    $filterSql .= " AND (r.voter_registered='Yes' OR LOWER(COALESCE(r.voter_status,''))='registered') ";
  } else if ($voter === 'not_registered') {
    $filterSql .= " AND (r.voter_registered='No' AND LOWER(COALESCE(r.voter_status,''))!='registered') ";
  }
  if ($voterOnly) { $filterSql .= " AND (r.voter_registered='Yes' OR LOWER(COALESCE(r.voter_status,''))='registered') "; }
  if ($ageMin !== null) { $filterSql .= ' AND COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) >= :age_min '; $params[':age_min'] = $ageMin; }
  if ($ageMax !== null) { $filterSql .= ' AND COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) <= :age_max '; $params[':age_max'] = $ageMax; }
  if ($ageBucket) {
    $filterSql .= ' AND (CASE WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) <= 17 THEN \"0-17\" '
               .  ' WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) BETWEEN 18 AND 35 THEN \"18-35\" '
               .  ' WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) BETWEEN 36 AND 59 THEN \"36-59\" '
               .  ' ELSE \"60+\" END) = :age_bucket ';
    $params[':age_bucket'] = $ageBucket;
  }

  // Totals
  $stmt = $pdo->prepare("SELECT COUNT(*) AS residents FROM residents r" . $filterSql);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();
  $totalResidents = (int)$stmt->fetchColumn();

  // Households are only scoped by purok (not by other resident filters)
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM households h" . ($purokId ? ' WHERE h.purok_id = :purok_id' : ''));
  if ($purokId) $stmt->bindParam(':purok_id', $purokId);
  $stmt->execute();
  $totalHouseholds = (int)$stmt->fetchColumn();

  $activeUsers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status='active'")->fetchColumn();

  // Users by role (admin, staff, purok)
  $usersByRole = ['admin'=>0,'staff'=>0,'purok'=>0];
  try {
    $rows = $pdo->query("SELECT role, COUNT(*) c FROM users WHERE status='active' GROUP BY role")->fetchAll();
    foreach ($rows as $r) { if (isset($usersByRole[$r['role']])) $usersByRole[$r['role']] = (int)$r['c']; }
  } catch (Throwable $e) { /* optional */ }

  // Gender distribution
  $sqlGender = "SELECT COALESCE(gender,'Other') AS gender, COUNT(*) AS c
                 FROM residents r" . $filterSql . " GROUP BY COALESCE(gender,'Other')";
  $stmt = $pdo->prepare($sqlGender);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();
  $gender = ['Male'=>0,'Female'=>0,'Other'=>0];
  foreach ($stmt->fetchAll() as $row) $gender[$row['gender']] = (int)$row['c'];

  // Age groups
  $sqlAge = "SELECT 
      CASE 
        WHEN age_val <= 17 THEN '0-17'
        WHEN age_val BETWEEN 18 AND 35 THEN '18-35'
        WHEN age_val BETWEEN 36 AND 59 THEN '36-59'
        ELSE '60+'
      END AS bucket,
      COUNT(*) AS c
    FROM (
      SELECT COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) AS age_val
      FROM residents r" . $filterSql . "
    ) t
    GROUP BY bucket";
  $stmt = $pdo->prepare($sqlAge);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();
  $ageGroups = ['0-17'=>0,'18-35'=>0,'36-59'=>0,'60+'=>0];
  foreach ($stmt->fetchAll() as $row) $ageGroups[$row['bucket']] = (int)$row['c'];

  // Purok population breakdown (for bars)
  $sqlPurok = "SELECT p.name, COUNT(r.id) AS c
               FROM puroks p
               LEFT JOIN residents r ON r.purok_id = p.id
               " . ($purokId ? ' WHERE p.id = :purok_id ' : '') .
               " GROUP BY p.id, p.name ORDER BY p.name";
  $stmt = $pdo->prepare($sqlPurok);
  if ($purokId) $stmt->bindParam(':purok_id', $purokId);
  $stmt->execute();
  $purokLabels = []; $purokCounts = [];
  foreach ($stmt->fetchAll() as $row) { $purokLabels[] = $row['name']; $purokCounts[] = (int)$row['c']; }

  // Voter registration breakdown (registered vs not)
  $voters = ['Registered'=>0,'Not Registered'=>0];
  try {
    $sqlVoter = "SELECT CASE 
                  WHEN COALESCE(voter_registered,0)=1 
                       OR LOWER(COALESCE(voter_status,''))='registered' 
                       OR LOWER(COALESCE(voter_registered,'')) IN ('yes','y','true','1')
                  THEN 'Registered'
                  ELSE 'Not Registered' END AS vs, COUNT(*) AS c
                FROM residents r" . $filterSql . " GROUP BY vs";
    $stmt = $pdo->prepare($sqlVoter);
    foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
    $stmt->execute();
    foreach ($stmt->fetchAll() as $row) { $voters[$row['vs']] = (int)$row['c']; }
  } catch (Throwable $e) { /* column may not exist; keep zeros */ }

  // Occupation breakdown (top 5)
  $occLabels = []; $occCounts = [];
  try {
    $sqlOcc = "SELECT COALESCE(occupation,'Unknown') AS occ, COUNT(*) AS c
               FROM residents r" . $filterSql . " GROUP BY occ ORDER BY c DESC LIMIT 5";
    $stmt = $pdo->prepare($sqlOcc);
    foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
    $stmt->execute();
    foreach ($stmt->fetchAll() as $row) { $occLabels[] = $row['occ']; $occCounts[] = (int)$row['c']; }
  } catch (Throwable $e) { /* optional */ }

  // Daily added residents (last 7 days)
  $daily = ['labels'=>[], 'data'=>[]];
  try {
    $sqlDaily = "SELECT DATE(created_at) d, COUNT(*) c FROM residents r" . ($purokId ? ' WHERE r.purok_id = :purok_id ' : ' ') .
               " GROUP BY DATE(created_at) ORDER BY d DESC LIMIT 7";
    $stmt = $pdo->prepare($sqlDaily);
    if ($purokId) $stmt->bindParam(':purok_id', $purokId);
    $stmt->execute();
    $rows = array_reverse($stmt->fetchAll());
    foreach ($rows as $row) { $daily['labels'][] = $row['d']; $daily['data'][] = (int)$row['c']; }
  } catch (Throwable $e) { /* optional */ }

  echo json_encode([
    'ok' => true,
    'totals' => [
      'residents' => $totalResidents,
      'households' => $totalHouseholds,
      'active_users' => $activeUsers,
      'users_by_role' => $usersByRole
    ],
    'gender' => [ 'labels' => array_keys($gender), 'data' => array_values($gender) ],
    'age_groups' => [ 'labels' => array_keys($ageGroups), 'data' => array_values($ageGroups) ],
    'purok_population' => [ 'labels' => $purokLabels, 'data' => $purokCounts ],
    'voters' => [ 'labels' => array_keys($voters), 'data' => array_values($voters) ],
    'occupation' => [ 'labels' => $occLabels, 'data' => $occCounts ],
    'daily_added' => $daily
  ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false, 'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
