<?php
require_once __DIR__ . '/db_config.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

function log_action(string $action_type, string $entity, $entity_id = null, array $details = [], $purok_id = null): void {
  try {
    $pdo = DB::pdo();
    $uid = $_SESSION['user_id'] ?? null;
    $role = $_SESSION['role'] ?? null;
    if ($purok_id === null && isset($_SESSION['purok_id'])) $purok_id = $_SESSION['purok_id'];
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, role, action_type, entity, entity_id, details, purok_id, created_at)
                           VALUES (:uid, :role, :atype, :ent, :eid, :det, :purok_id, NOW())");
    $detJson = $details ? json_encode($details) : null;
    $stmt->execute([
      ':uid' => $uid,
      ':role' => $role,
      ':atype' => $action_type,
      ':ent' => $entity,
      ':eid' => $entity_id,
      ':det' => $detJson,
      ':purok_id' => $purok_id,
    ]);
  } catch (Throwable $e) { /* swallow logging errors */ }
}

function recent_actions(int $limit = 20, ?int $purokScope = null, ?string $startDate = null, ?string $endDate = null, ?string $username = null, ?string $action = null): array {
  $pdo = DB::pdo();
  $sql = "SELECT al.id, al.created_at, al.user_id, al.role, al.action_type, al.entity, al.entity_id, al.details, al.purok_id,
                 u.username
          FROM activity_logs al
          LEFT JOIN users u ON u.id = al.user_id
          WHERE 1=1 ";
  $params = [];
  if ($purokScope !== null) { $sql .= " AND al.purok_id = :pid"; $params[':pid'] = $purokScope; }
  if ($startDate) { $sql .= ' AND DATE(al.created_at) >= :sd'; $params[':sd'] = $startDate; }
  if ($endDate) { $sql .= ' AND DATE(al.created_at) <= :ed'; $params[':ed'] = $endDate; }
  if ($username) { $sql .= ' AND (u.username LIKE :un)'; $params[':un'] = '%'.$username.'%'; }
  if ($action) { $sql .= ' AND al.action_type = :act'; $params[':act'] = $action; }
  $sql .= " ORDER BY al.created_at DESC LIMIT :lim";
  $stmt = $pdo->prepare($sql);
  foreach ($params as $k=>$v) $stmt->bindValue($k, $v);
  $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
  $stmt->execute();
  $rows = $stmt->fetchAll();
  foreach ($rows as &$r) {
    if (isset($r['details']) && $r['details']) {
      $decoded = json_decode($r['details'], true);
      if (json_last_error() === JSON_ERROR_NONE) $r['details'] = $decoded;
    }
  }
  return $rows;
}
