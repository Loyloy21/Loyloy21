<?php
// Handles login authentication. Expects POST: username, password, role
require_once __DIR__ . '/db_config.php';
require_once __DIR__ . '/activity_log.php';
// avoid emitting notices/warnings in JSON response
@ini_set('display_errors','0');
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
header('Content-Type: application/json');
header('Cache-Control: no-store');

try {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method Not Allowed']);
    exit;
  }

  // Support form-encoded or JSON payloads
  $input = $_POST;
  if (empty($input)) {
    $raw = file_get_contents('php://input');
    if ($raw) {
      $decoded = json_decode($raw, true);
      if (is_array($decoded)) $input = $decoded;
    }
  }

  $username = isset($input['username']) ? trim($input['username']) : '';
  $password = isset($input['password']) ? (string)$input['password'] : '';
  $role     = isset($input['role']) ? trim($input['role']) : '';

  if ($username === '' || $password === '' || $role === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing credentials']);
    exit;
  }

  $pdo = DB::pdo();

  // Normalize requested role to match DB (support both 'purok' and 'purok_leader')
  $dbRole = $role;
  if ($role === 'purok_leader') {
    $dbRole = 'purok';
  }

  // Look up active user by username + normalized role
  $stmt = $pdo->prepare("SELECT id, username, password_hash, role, status, full_name, purok_id FROM users WHERE username = :u AND role = :r AND status = 'active' LIMIT 1");
  $stmt->execute([':u' => $username, ':r' => $dbRole]);
  $user = $stmt->fetch();

  // Optional: back-compat if table stores plaintext (not recommended). Only use password_hash moving forward.
  $isValid = false;
  if ($user) {
    if (!empty($user['password_hash'])) {
      $isValid = password_verify($password, $user['password_hash']);
    }
  }

  if (!$user || !$isValid) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Invalid username or password']);
    exit;
  }

  // Regenerate session to prevent fixation
  session_regenerate_id(true);
  $_SESSION['user_id'] = $user['id'];
  $_SESSION['username'] = $user['username'];
  $_SESSION['role'] = $user['role'];
  $_SESSION['full_name'] = isset($user['full_name']) ? $user['full_name'] : $user['username'];
  $_SESSION['logged_in'] = true;
  if (isset($user['purok_id'])) { $_SESSION['purok_id'] = $user['purok_id']; }

  // Suggest redirect based on stored user role
  $redirect = '../admin/admin_dashboard.php';
  if ($user['role'] === 'staff')        $redirect = '../population/population_dashboard.php';
  if ($user['role'] === 'purok' || $user['role'] === 'purok_leader') $redirect = '../purok/purok_dashboard.php';

  echo json_encode(['ok' => true, 'redirect' => $redirect]);
  // Log login event (non-blocking if fails)
  log_action('login', 'user', $user['id'], ['username'=>$user['username'],'role'=>$user['role']]);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
