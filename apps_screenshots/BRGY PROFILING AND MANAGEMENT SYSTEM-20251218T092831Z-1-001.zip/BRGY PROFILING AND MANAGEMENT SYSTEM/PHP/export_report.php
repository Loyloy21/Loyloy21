<?php
require_once __DIR__ . '/db_config.php';
session_start();
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');

try {
  $pdo = DB::pdo();
  // Filters (same as stats.php)
  $purokId = isset($_GET['purok_id']) && $_GET['purok_id'] !== '' ? (int)$_GET['purok_id'] : null;
  if (isset($_SESSION['role']) && $_SESSION['role'] === 'purok' && !empty($_SESSION['purok_id'])) {
    $purokId = (int)$_SESSION['purok_id'];
  }
  $gender = isset($_GET['gender']) && $_GET['gender'] !== '' ? $_GET['gender'] : null;
  $ageBucket = isset($_GET['age_bucket']) && $_GET['age_bucket'] !== '' ? $_GET['age_bucket'] : null; // '0-17','18-35','36-59','60+'
  $voter = isset($_GET['voter']) && $_GET['voter'] !== '' ? strtolower($_GET['voter']) : null; // 'registered'|'not_registered'

  $filterSql = ' WHERE 1=1 ';
  $params = [];
  if ($purokId) { $filterSql .= ' AND r.purok_id = :purok_id '; $params[':purok_id'] = $purokId; }
  if ($gender) { $filterSql .= ' AND COALESCE(r.gender,\'Other\') = :gender '; $params[':gender'] = $gender; }
  if ($voter === 'registered') {
    $filterSql .= " AND (COALESCE(r.voter_registered,0)=1 OR LOWER(COALESCE(r.voter_status,''))='registered') ";
  } else if ($voter === 'not_registered') {
    $filterSql .= " AND (COALESCE(r.voter_registered,0)=0 AND LOWER(COALESCE(r.voter_status,''))!='registered') ";
  }
  if ($ageBucket) {
    $filterSql .= ' AND (CASE WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) <= 17 THEN \"0-17\" '
               .  ' WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) BETWEEN 18 AND 35 THEN \"18-35\" '
               .  ' WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) BETWEEN 36 AND 59 THEN \"36-59\" '
               .  ' ELSE \"60+\" END) = :age_bucket ';
    $params[':age_bucket'] = $ageBucket;
  }

  // Totals
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM residents r" . $filterSql);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();
  $totalResidents = (int)$stmt->fetchColumn();

  $stmt = $pdo->prepare("SELECT COUNT(*) FROM households h" . ($purokId ? ' WHERE h.purok_id = :purok_id' : ''));
  if ($purokId) $stmt->bindParam(':purok_id', $purokId);
  $stmt->execute();
  $totalHouseholds = (int)$stmt->fetchColumn();

  // Voters
  $voters = ['Registered'=>0,'Not Registered'=>0];
  $sqlVoter = "SELECT CASE 
                  WHEN COALESCE(voter_registered,0)=1 OR LOWER(COALESCE(voter_status,''))='registered' THEN 'Registered'
                  ELSE 'Not Registered' END AS vs, COUNT(*) AS c
                FROM residents r" . $filterSql . " GROUP BY vs";
  $stmt = $pdo->prepare($sqlVoter);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();
  foreach ($stmt->fetchAll() as $row) { $voters[$row['vs']] = (int)$row['c']; }

  // Gender
  $genderData = ['Male'=>0,'Female'=>0,'Other'=>0];
  $sqlGender = "SELECT COALESCE(gender,'Other') AS g, COUNT(*) c FROM residents r" . $filterSql . " GROUP BY COALESCE(gender,'Other')";
  $stmt = $pdo->prepare($sqlGender);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();
  foreach ($stmt->fetchAll() as $row) { $genderData[$row['g']] = (int)$row['c']; }

  // Age groups
  $ageGroups = ['0-17'=>0,'18-35'=>0,'36-59'=>0,'60+'=>0];
  $sqlAge = "SELECT 
      CASE 
        WHEN age_val <= 17 THEN '0-17'
        WHEN age_val BETWEEN 18 AND 35 THEN '18-35'
        WHEN age_val BETWEEN 36 AND 59 THEN '36-59'
        ELSE '60+'
      END AS bucket, COUNT(*) AS c
    FROM (SELECT COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) AS age_val FROM residents r" . $filterSql . ") t
    GROUP BY bucket";
  $stmt = $pdo->prepare($sqlAge);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();
  foreach ($stmt->fetchAll() as $row) { $ageGroups[$row['bucket']] = (int)$row['c']; }

  // Optional list (limited)
  $sqlList = "SELECT r.id, p.name AS purok, r.full_name, COALESCE(r.gender,'') gender,
                     DATE_FORMAT(r.birth_date,'%Y-%m-%d') birth_date,
                     COALESCE(r.occupation,'') occupation,
                     (COALESCE(r.voter_registered,0)) vr, COALESCE(r.voter_status,'') vs
              FROM residents r LEFT JOIN puroks p ON p.id=r.purok_id" . $filterSql . " ORDER BY p.name, r.full_name LIMIT 200";
  $stmt = $pdo->prepare($sqlList);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();
  $rows = $stmt->fetchAll();

  $printedAt = date('Y-m-d H:i');
  $title = 'Barangay Profiling Report';
  $scope = $purokId ? 'Purok ID: '.$purokId : 'All Puroks';
} catch (Throwable $e) {
  echo '<h2>Error generating report</h2><pre>'.htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8').'</pre>'; exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= htmlspecialchars($title) ?></title>
  <style>
    body { font-family: system-ui, Arial, sans-serif; color:#111; padding: 20px; }
    header { display:flex; align-items:center; justify-content:space-between; border-bottom:2px solid #ccc; padding-bottom:8px; margin-bottom:16px; }
    header .meta { color:#444; font-size: 13px; }
    .cards { display:grid; grid-template-columns: repeat(auto-fit, minmax(180px,1fr)); gap:10px; margin: 12px 0 18px; }
    .card { border:1px solid #ddd; border-radius:10px; padding:12px; background:#fafafa; }
    h2 { margin: 18px 0 8px; }
    table { width:100%; border-collapse: collapse; font-size: 13px; }
    th, td { border:1px solid #ddd; padding:6px 8px; text-align:left; }
    th { background:#f3f4f6; }
    .actions { margin: 10px 0 16px; }
    @media print { .actions { display:none; } body { padding:0; } }
  </style>
</head>
<body>
  <header>
    <div>
      <h1 style="margin:0;"><?= htmlspecialchars($title) ?></h1>
      <div class="meta">Scope: <?= htmlspecialchars($scope) ?> • Printed: <?= htmlspecialchars($printedAt) ?></div>
    </div>
    <img src="../assets/images/logo.png" alt="Logo" style="width:56px;height:56px;border-radius:50%;" />
  </header>

  <div class="actions">
    <button onclick="window.print()">Print / Save as PDF</button>
  </div>

  <section class="cards">
    <div class="card"><strong>Total Residents</strong><div><?= (int)$totalResidents ?></div></div>
    <div class="card"><strong>Total Households</strong><div><?= (int)$totalHouseholds ?></div></div>
    <div class="card"><strong>Registered Voters</strong><div><?= (int)$voters['Registered'] ?></div></div>
    <div class="card"><strong>Not Registered</strong><div><?= (int)$voters['Not Registered'] ?></div></div>
  </section>

  <section>
    <h2>Gender Breakdown</h2>
    <table>
      <thead><tr><th>Gender</th><th>Count</th></tr></thead>
      <tbody>
        <tr><td>Male</td><td><?= (int)$genderData['Male'] ?></td></tr>
        <tr><td>Female</td><td><?= (int)$genderData['Female'] ?></td></tr>
        <tr><td>Other</td><td><?= (int)$genderData['Other'] ?></td></tr>
      </tbody>
    </table>
  </section>

  <section>
    <h2>Age Groups</h2>
    <table>
      <thead><tr><th>Bucket</th><th>Count</th></tr></thead>
      <tbody>
        <?php foreach ($ageGroups as $k=>$v): ?>
          <tr><td><?= htmlspecialchars($k) ?></td><td><?= (int)$v ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </section>

  <section>
    <h2>Sample Residents (up to 200)</h2>
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Purok</th><th>Full Name</th><th>Gender</th><th>Birth Date</th><th>Occupation</th><th>Voter</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= (int)$r['id'] ?></td>
            <td><?= htmlspecialchars($r['purok'] ?? '') ?></td>
            <td><?= htmlspecialchars($r['full_name'] ?? '') ?></td>
            <td><?= htmlspecialchars($r['gender'] ?? '') ?></td>
            <td><?= htmlspecialchars($r['birth_date'] ?? '') ?></td>
            <td><?= htmlspecialchars($r['occupation'] ?? '') ?></td>
            <td><?= ((int)$r['vr']) ? 'Registered' : 'Not Registered' ?><?= $r['vs']?(' ('.htmlspecialchars($r['vs']).')'):'' ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </section>
</body>
</html>
