<?php
require_once __DIR__ . '/db_config.php';
require_once __DIR__ . '/activity_log.php';
session_start();
header('Content-Type: application/json');
header('Cache-Control: no-store');
@ini_set('display_errors','0');

if (empty($_SESSION['logged_in'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Unauthorized'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }

function role_scope_purok(): ?string {
  return (isset($_SESSION['role']) && $_SESSION['role'] === 'purok' && !empty($_SESSION['purok_id'])) ? (string)$_SESSION['purok_id'] : null;
}

function body_json(): array {
  $raw = file_get_contents('php://input');
  if ($raw) { $d = json_decode($raw, true); if (is_array($d)) return $d; }
  return $_POST ?: [];
}

try {
  $pdo = DB::pdo();
  $method = $_SERVER['REQUEST_METHOD'];
  $action = $_GET['action'] ?? $_POST['action'] ?? null;

  // List
  if ($method === 'GET' && (!$action || $action === 'list')) {
    $purokId = $_GET['purok_id'] ?? null;
    $scope = role_scope_purok(); if ($scope !== null) { $purokId = $scope; }
    $sql = "SELECT h.*, p.name AS purok_name FROM households h LEFT JOIN puroks p ON p.id = h.purok_id WHERE 1=1";
    $params = [];
    if ($purokId) { $sql .= ' AND h.purok_id = :purok_id'; $params[':purok_id'] = $purokId; }
    $sql .= ' ORDER BY h.id DESC LIMIT 500';
    $stmt = $pdo->prepare($sql);
    foreach ($params as $k=>$v) $stmt->bindValue($k, $v);
    $stmt->execute();
    echo json_encode(['ok'=>true,'data'=>$stmt->fetchAll()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Create
  if ($method === 'POST' && $action === 'create') {
    $in = body_json();
    $purok_id = (string)($in['purok_id'] ?? '');
    $scope = role_scope_purok(); if ($scope !== null) { $purok_id = (string)$scope; }
    if ($purok_id==='') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'purok_id required'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    // validate purok exists
    $chkP = $pdo->prepare('SELECT id FROM puroks WHERE id=:pid LIMIT 1');
    $chkP->execute([':pid'=>$purok_id]);
    if (!$chkP->fetchColumn()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid purok_id (not found): '.$purok_id], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    $head = trim($in['household_no'] ?? '');
    $address = $in['address'] ?? null;

    $stmt = $pdo->prepare("INSERT INTO households (purok_id, household_no, address)
                           VALUES (:purok_id, :head, :addr)");
    $stmt->execute([':purok_id'=>$purok_id, ':head'=>$head, ':addr'=>$address]);
    // UUID PK may not be returned by lastInsertId in MariaDB; respond without id
    log_action('create','household',null,['purok_id'=>$purok_id,'household_no'=>$head]);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Update
  if ($method === 'POST' && $action === 'update') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); if ($id===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    $scope = role_scope_purok();
    if ($scope !== null) {
      $chk = $pdo->prepare('SELECT purok_id FROM households WHERE id=:id'); $chk->execute([':id'=>$id]); $hid = $chk->fetchColumn();
      if ((string)$hid !== (string)$scope) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'Forbidden'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    }
    $fields = ['household_no','address'];
    $sets=[]; $params=[':id'=>$id];
    foreach($fields as $f){ if (array_key_exists($f,$in)) { $sets[] = "$f = :$f"; $params[":$f"] = $in[$f]; } }
    if (!$sets) { echo json_encode(['ok'=>true,'updated'=>0], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    $sql = 'UPDATE households SET '.implode(', ',$sets).' WHERE id=:id';
    $stmt = $pdo->prepare($sql); $stmt->execute($params);
    log_action('update','household',$id,$in);
    echo json_encode(['ok'=>true,'updated'=>$stmt->rowCount()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Delete
  if ($method === 'POST' && $action === 'delete') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); if ($id===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required']); exit; }
    $scope = role_scope_purok();
    if ($scope !== null) {
      $chk = $pdo->prepare('SELECT purok_id FROM households WHERE id=:id'); $chk->execute([':id'=>$id]); $hid = $chk->fetchColumn();
      if ((string)$hid !== (string)$scope) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'Forbidden']); exit; }
    }
    $pdo->prepare('DELETE FROM households WHERE id=:id')->execute([':id'=>$id]);
    log_action('delete','household',$id,[]);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'Unsupported action'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
