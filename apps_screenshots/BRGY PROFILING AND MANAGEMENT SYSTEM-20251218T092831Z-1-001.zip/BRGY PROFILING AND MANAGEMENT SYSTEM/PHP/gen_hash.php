<?php
$hash = '';
$pwd = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $pwd = isset($_POST['password']) ? (string)$_POST['password'] : '';
  if ($pwd !== '') {
    $hash = password_hash($pwd, PASSWORD_DEFAULT);
  }
}
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Password Hash Generator</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body { font-family: system-ui, Arial, sans-serif; padding: 24px; max-width: 680px; margin: 0 auto; }
    label { display:block; margin: 12px 0 6px; }
    input[type=password], input[type=text] { width: 100%; padding: 10px; font-size: 16px; }
    button { margin-top: 12px; padding: 10px 16px; font-size: 16px; cursor: pointer; }
    .out { margin-top: 16px; padding: 12px; background: #f6f6f6; border: 1px solid #ddd; word-break: break-all; }
  </style>
</head>
<body>
  <h1>Password Hash Generator</h1>
  <form method="post">
    <label for="password">Enter password to hash</label>
    <input type="password" id="password" name="password" required />
    <button type="submit">Generate Hash</button>
  </form>
  <?php if ($hash): ?>
    <div class="out">
      <div><strong>Password:</strong> <?php echo htmlspecialchars($pwd, ENT_QUOTES, 'UTF-8'); ?></div>
      <div style="margin-top:8px;"><strong>Hash:</strong></div>
      <input type="text" value="<?php echo htmlspecialchars($hash, ENT_QUOTES, 'UTF-8'); ?>" readonly onclick="this.select();" />
      <p style="margin-top:8px; color:#555;">Copy the hash and use it in your INSERT statement as the value for password_hash.</p>
    </div>
  <?php endif; ?>
</body>
</html>
