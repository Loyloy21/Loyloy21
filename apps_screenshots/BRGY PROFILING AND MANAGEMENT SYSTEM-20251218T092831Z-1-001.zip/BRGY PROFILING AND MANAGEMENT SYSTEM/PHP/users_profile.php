<?php
require_once __DIR__ . '/db_config.php';
require_once __DIR__ . '/activity_log.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
header('Content-Type: application/json');
header('Cache-Control: no-store');
@ini_set('display_errors','0');

function body_json(): array {
  $raw = file_get_contents('php://input');
  if ($raw) { $d = json_decode($raw, true); if (is_array($d)) return $d; }
  return $_POST ?: [];
}

try {
  if (empty($_SESSION['logged_in'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Unauthorized']); exit; }
  $user_id = (string)$_SESSION['user_id'];
  $pdo = DB::pdo();
  $method = $_SERVER['REQUEST_METHOD'];
  $action = $_GET['action'] ?? $_POST['action'] ?? null;

  // GET profile of current user
  if ($method==='GET' && (!$action || $action==='me')) {
    $stmt = $pdo->prepare("SELECT id, username, full_name, role, status, purok_id, created_at FROM users WHERE id=:id LIMIT 1");
    $stmt->execute([':id'=>$user_id]);
    $u = $stmt->fetch();
    if (!$u) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'Not found']); exit; }
    // attach photo_url if exists
    $photoPathJpg = __DIR__ . '/../assets/uploads/users/' . $user_id . '.jpg';
    $photoPathPng = __DIR__ . '/../assets/uploads/users/' . $user_id . '.png';
    $photoUrl = null;
    if (file_exists($photoPathJpg)) { $photoUrl = '../assets/uploads/users/' . $user_id . '.jpg'; }
    else if (file_exists($photoPathPng)) { $photoUrl = '../assets/uploads/users/' . $user_id . '.png'; }
    if ($photoUrl) { $u['photo_url'] = $photoUrl; }
    echo json_encode(['ok'=>true,'data'=>$u]);
    exit;
  }

  // Update profile (editable: full_name only for now)
  if ($method==='POST' && $action==='update') {
    $in = body_json();
    $full_name = isset($in['full_name']) ? trim((string)$in['full_name']) : '';
    if ($full_name===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'full_name required']); exit; }
    $stmt = $pdo->prepare('UPDATE users SET full_name=:fn WHERE id=:id');
    $stmt->execute([':fn'=>$full_name, ':id'=>$user_id]);
    log_action('update','user',$user_id,['profile_update'=>['full_name'=>$full_name]]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  // Change password (requires current password)
  if ($method==='POST' && $action==='change_password') {
    $in = body_json();
    $current = (string)($in['current_password'] ?? '');
    $next = (string)($in['new_password'] ?? '');
    if ($current==='' || $next===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'current_password and new_password required']); exit; }
    $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id=:id');
    $stmt->execute([':id'=>$user_id]);
    $row = $stmt->fetch();
    if (!$row || empty($row['password_hash']) || !password_verify($current, $row['password_hash'])){
      http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Current password is incorrect']); exit; }
    $hash = password_hash($next, PASSWORD_DEFAULT);
    $pdo->prepare('UPDATE users SET password_hash=:ph WHERE id=:id')->execute([':ph'=>$hash, ':id'=>$user_id]);
    log_action('update','user',$user_id,['change_password'=>true]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'Unsupported action']);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
