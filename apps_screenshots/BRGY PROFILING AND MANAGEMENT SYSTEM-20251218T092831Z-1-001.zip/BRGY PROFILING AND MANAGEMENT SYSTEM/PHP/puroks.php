<?php
require_once __DIR__ . '/db_config.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');
@ini_set('display_errors','0');
try {
  $pdo = DB::pdo();
  $stmt = $pdo->query("SELECT id, name FROM puroks ORDER BY name");
  echo json_encode(['ok'=>true,'data'=>$stmt->fetchAll()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
