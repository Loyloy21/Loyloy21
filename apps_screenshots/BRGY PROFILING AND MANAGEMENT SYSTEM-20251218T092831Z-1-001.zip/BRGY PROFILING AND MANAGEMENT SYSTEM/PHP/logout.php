<?php
session_start();
// optional logging
try { require_once __DIR__ . '/activity_log.php'; if (!empty($_SESSION['user_id'])) { log_action('logout','user', $_SESSION['user_id'], ['username'=>($_SESSION['username']??null),'role'=>($_SESSION['role']??null)]); } } catch (Throwable $e) {}
$_SESSION = [];
if (ini_get('session.use_cookies')) {
  $params = session_get_cookie_params();
  setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();
header('Content-Type: application/json');
echo json_encode(['ok' => true]);
