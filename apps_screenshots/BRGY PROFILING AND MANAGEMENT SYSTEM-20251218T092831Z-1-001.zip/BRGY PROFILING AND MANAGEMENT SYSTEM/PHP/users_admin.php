<?php
require_once __DIR__ . '/db_config.php';
require_once __DIR__ . '/activity_log.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
header('Content-Type: application/json');
header('Cache-Control: no-store');
@ini_set('display_errors','0');

if (empty($_SESSION['logged_in']) || ($_SESSION['role'] ?? '') !== 'admin') {
  http_response_code(403);
  echo json_encode(['ok'=>false,'error'=>'Forbidden'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
  exit;
}

function body_json(): array {
  $raw = file_get_contents('php://input');
  if ($raw) { $d = json_decode($raw, true); if (is_array($d)) return $d; }
  return $_POST ?: [];
}

try {
  $pdo = DB::pdo();
  $method = $_SERVER['REQUEST_METHOD'];
  $action = $_GET['action'] ?? $_POST['action'] ?? null;

  // List users
  if ($method === 'GET' && (!$action || $action === 'list')) {
    $stmt = $pdo->query("SELECT id, username, full_name, role, status, purok_id, created_at FROM users ORDER BY role, username");
    echo json_encode(['ok'=>true,'data'=>$stmt->fetchAll()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Create user (admin/staff/purok)
  if ($method === 'POST' && $action === 'create') {
    $in = body_json();
    $username = trim($in['username'] ?? '');
    $password = (string)($in['password'] ?? '');
    $role = trim($in['role'] ?? '');
    $full_name = trim($in['full_name'] ?? '');
    $purok_id = isset($in['purok_id']) && $in['purok_id'] !== '' ? (string)$in['purok_id'] : null;

    if ($username === '' || $password === '' || !in_array($role, ['admin','staff','purok'], true)) {
      http_response_code(400); echo json_encode(['ok'=>false,'error'=>'username, password, role required'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit;
    }
    if ($role === 'purok' && empty($purok_id)) {
      http_response_code(400); echo json_encode(['ok'=>false,'error'=>'purok_id required for purok user'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit;
    }
    if ($role === 'purok' && $purok_id) {
      $chk = $pdo->prepare('SELECT id FROM puroks WHERE id=:id LIMIT 1');
      $chk->execute([':id'=>$purok_id]);
      if (!$chk->fetchColumn()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid purok_id (not found)'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role, status, full_name, purok_id, created_at)
                           VALUES (:u, :ph, :r, 'active', :fn, :pid, NOW())");
    $stmt->execute([':u'=>$username, ':ph'=>$hash, ':r'=>$role, ':fn'=>$full_name ?: null, ':pid'=>$purok_id]);
    log_action('create','user',null,['username'=>$username,'role'=>$role,'purok_id'=>$purok_id]);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Update user (full_name, role, status, purok_id; not password here)
  if ($method === 'POST' && $action === 'update') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); if ($id===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    $fields = ['full_name','role','status','purok_id'];
    $sets=[]; $params=[':id'=>$id];
    foreach($fields as $f){ if (array_key_exists($f,$in)) { $sets[] = "$f = :$f"; $params[":$f"] = $in[$f]; } }
    if (!$sets) { echo json_encode(['ok'=>true,'updated'=>0], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    $sql = 'UPDATE users SET '.implode(', ',$sets).' WHERE id=:id';
    $stmt = $pdo->prepare($sql); $stmt->execute($params);
    log_action('update','user',$id,$in);
    echo json_encode(['ok'=>true,'updated'=>$stmt->rowCount()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Deactivate user
  if ($method === 'POST' && $action === 'deactivate') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); if ($id===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required']); exit; }
    $pdo->prepare("UPDATE users SET status='disabled' WHERE id=:id")->execute([':id'=>$id]);
    log_action('update','user',$id,['status'=>'disabled']);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Reactivate user
  if ($method === 'POST' && $action === 'reactivate') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); if ($id===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required']); exit; }
    $pdo->prepare("UPDATE users SET status='active' WHERE id=:id")->execute([':id'=>$id]);
    log_action('update','user',$id,['status'=>'active']);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Delete user (hard delete)
  if ($method === 'POST' && $action === 'delete') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); if ($id===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required']); exit; }
    // Prevent deleting currently logged-in user
    if (isset($_SESSION['user_id']) && (string)$_SESSION['user_id'] === $id){
      http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Cannot delete your own account'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit;
    }
    $stmt = $pdo->prepare('DELETE FROM users WHERE id=:id');
    $stmt->execute([':id'=>$id]);
    log_action('delete','user',$id,[]);
    echo json_encode(['ok'=>true,'deleted'=>$stmt->rowCount()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Reset password
  if ($method === 'POST' && $action === 'reset_password') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); $password = (string)($in['password'] ?? '');
    if ($id==='' || $password===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id and password required'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $pdo->prepare('UPDATE users SET password_hash=:ph WHERE id=:id')->execute([':ph'=>$hash, ':id'=>$id]);
    log_action('update','user',$id,['reset_password'=>true]);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'Unsupported action'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
