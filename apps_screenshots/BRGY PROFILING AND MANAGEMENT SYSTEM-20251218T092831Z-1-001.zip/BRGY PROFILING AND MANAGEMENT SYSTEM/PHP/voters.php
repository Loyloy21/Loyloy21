<?php
require_once __DIR__ . '/db_config.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
@ini_set('display_errors','0');

// Simple access guard: require admin session for AJAX
if (empty($_SESSION['logged_in']) || (($_SESSION['role'] ?? '') !== 'admin')) {
  http_response_code(403);
  header('Content-Type: application/json');
  echo json_encode(['success'=>false,'message'=>'Forbidden']);
  exit;
}

$pdo = DB::pdo();

$action = $_GET['action'] ?? '';

switch ($action) {
  case 'getStatistics':
    header('Content-Type: application/json');
    getVoterStatistics($pdo);
    break;
  case 'getRegistrationReport':
    header('Content-Type: application/json');
    $year = $_GET['year'] ?? date('Y');
    getRegistrationReport($pdo, $year);
    break;
  case 'exportData':
    exportVoterDataCSV($pdo);
    break;
  default:
    header('Content-Type: application/json');
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Invalid action']);
}

/**
 * Get voter statistics
 */
function getVoterStatistics(PDO $pdo) {
    try {
        // Get total voters
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM residents WHERE voter_status = 'Registered'");
        $totalVoters = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Get male voters
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM residents WHERE voter_status = 'Registered' AND gender = 'Male'");
        $maleVoters = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Get female voters
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM residents WHERE voter_status = 'Registered' AND gender = 'Female'");
        $femaleVoters = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Get non-voters
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM residents WHERE voter_status != 'Registered' OR voter_status IS NULL");
        $nonVoters = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Get voter distribution by purok
        $stmt = $pdo->query("
            SELECT p.name as purok_name, COUNT(r.id) as voter_count 
            FROM puroks p 
            LEFT JOIN residents r ON p.id = r.purok_id AND r.voter_status = 'Registered'
            GROUP BY p.id, p.name
            ORDER BY p.name
        ");
        $purokDistribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get age distribution of voters
        $stmt = $pdo->query("
            SELECT age, COUNT(*) as count 
            FROM residents 
            WHERE voter_status = 'Registered' AND age IS NOT NULL
            GROUP BY age
            ORDER BY age
        ");
        $ageDistribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Return the data
        echo json_encode([
            'success' => true,
            'totalVoters' => (int)$totalVoters,
            'maleVoters' => (int)$maleVoters,
            'femaleVoters' => (int)$femaleVoters,
            'nonVoters' => (int)$nonVoters,
            'purokDistribution' => $purokDistribution,
            'ageDistribution' => $ageDistribution
        ]);
        
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Get voter registration report by year
 */
function getRegistrationReport(PDO $pdo, $year) {
    try {
        // Initialize report data for all months
        $report = [];
        $months = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        
        // Initialize empty data for each month
        foreach ($months as $month) {
            $report[] = [
                'month' => $month,
                'new_voters' => 0,
                'male' => 0,
                'female' => 0,
                'total' => 0
            ];
        }
        
        // Get registration data from database
        $stmt = $pdo->prepare("
            SELECT 
                MONTH(created_at) as month,
                COUNT(*) as total,
                SUM(CASE WHEN gender = 'Male' THEN 1 ELSE 0 END) as male,
                SUM(CASE WHEN gender = 'Female' THEN 1 ELSE 0 END) as female
            FROM residents
            WHERE voter_status = 'Registered' 
            AND YEAR(created_at) = :year
            GROUP BY MONTH(created_at)
            ORDER BY MONTH(created_at)
        ");
        $stmt->execute(['year' => $year]);
        $dbData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Update report with actual data
        foreach ($dbData as $row) {
            $monthIndex = (int)$row['month'] - 1;
            if (isset($report[$monthIndex])) {
                $report[$monthIndex]['new_voters'] = (int)$row['total'];
                $report[$monthIndex]['male'] = (int)$row['male'];
                $report[$monthIndex]['female'] = (int)$row['female'];
                $report[$monthIndex]['total'] = (int)$row['total'];
            }
        }
        
        // Return the report
        echo json_encode([
            'success' => true,
            'report' => $report
        ]);
        
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Export voter data to CSV (Excel-compatible)
 */
function exportVoterDataCSV(PDO $pdo) {
    try {
        // Query data
        $stmt = $pdo->query("SELECT 
                r.id,
                r.last_name,
                r.first_name,
                r.middle_name,
                r.birth_date,
                r.age,
                r.gender,
                r.civil_status,
                r.contact_number,
                r.email,
                r.address,
                p.name AS purok_name,
                r.voter_status,
                r.created_at AS registration_date
            FROM residents r
            LEFT JOIN puroks p ON p.id = r.purok_id
            ORDER BY r.last_name, r.first_name");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // CSV headers (Excel-compatible)
        $filename = 'voter-data-' . date('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Cache-Control: no-store');

        $out = fopen('php://output', 'w');
        // BOM for Excel UTF-8
        fwrite($out, "\xEF\xBB\xBF");

        fputcsv($out, ['ID','Last Name','First Name','Middle Name','Birth Date','Age','Gender','Civil Status','Contact Number','Email','Address','Purok','Voter Status','Registration Date']);
        foreach ($rows as $r) {
          fputcsv($out, [
            $r['id'],$r['last_name'],$r['first_name'],$r['middle_name'],$r['birth_date'],$r['age'],$r['gender'],$r['civil_status'],$r['contact_number'],$r['email'],$r['address'],$r['purok_name'],$r['voter_status'],$r['registration_date']
          ]);
        }
        fclose($out);
        // Important: do not echo JSON after CSV
    } catch (Throwable $e) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success'=>false,'message'=>'Export error: '.$e->getMessage()]);
    }
}

?>
