<?php
require_once __DIR__ . '/db_config.php';
require_once __DIR__ . '/activity_log.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
header('Content-Type: application/json');
header('Cache-Control: no-store');
@ini_set('display_errors','0');

if (empty($_SESSION['logged_in'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Unauthorized'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }

try {
  $limit = isset($_GET['limit']) ? max(1, min(100, (int)$_GET['limit'])) : 20;
  $scopePurok = null;
  if (isset($_SESSION['role']) && $_SESSION['role'] === 'purok' && !empty($_SESSION['purok_id'])) {
    $scopePurok = (int)$_SESSION['purok_id'];
  }
  $start = isset($_GET['start_date']) && $_GET['start_date']!=='' ? $_GET['start_date'] : null;
  $end = isset($_GET['end_date']) && $_GET['end_date']!=='' ? $_GET['end_date'] : null;
  $user = isset($_GET['username']) && $_GET['username']!=='' ? $_GET['username'] : null;
  $action = isset($_GET['action']) && $_GET['action']!=='' ? $_GET['action'] : null;
  $rows = recent_actions($limit, $scopePurok, $start, $end, $user, $action);
  echo json_encode(['ok'=>true,'data'=>$rows], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
