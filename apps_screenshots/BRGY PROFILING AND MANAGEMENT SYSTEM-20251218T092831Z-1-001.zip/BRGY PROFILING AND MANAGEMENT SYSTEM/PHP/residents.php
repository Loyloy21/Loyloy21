<?php
require_once __DIR__ . '/db_config.php';
require_once __DIR__ . '/activity_log.php';
session_start();
header('Content-Type: application/json');
header('Cache-Control: no-store');
@ini_set('display_errors','0');

if (empty($_SESSION['logged_in'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Unauthorized'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }

function role_scope_purok(){
  return (isset($_SESSION['role']) && $_SESSION['role'] === 'purok' && !empty($_SESSION['purok_id'])) ? $_SESSION['purok_id'] : null;
}

function body_json(): array {
  $raw = file_get_contents('php://input');
  if ($raw) { $d = json_decode($raw, true); if (is_array($d)) return $d; }
  return $_POST ?: [];
}

try {
  $pdo = DB::pdo();
  $method = $_SERVER['REQUEST_METHOD'];
  $action = $_GET['action'] ?? $_POST['action'] ?? null;

  // List with filters
  if ($method === 'GET' && (!$action || $action === 'list')) {
    $purokId = $_GET['purok_id'] ?? null;
    $gender = $_GET['gender'] ?? null;
    $ageBucket = $_GET['age_bucket'] ?? null;
    $voter = isset($_GET['voter']) ? strtolower($_GET['voter']) : null;
    $voterOnly = isset($_GET['voter_only']) ? (int)$_GET['voter_only'] : 0;
    $scope = role_scope_purok(); if ($scope !== null) { $purokId = $scope; }

    $sql = "SELECT r.*, COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) AS age_calc, p.name AS purok_name
            FROM residents r LEFT JOIN puroks p ON p.id = r.purok_id WHERE 1=1";
    $params = [];
    if ($purokId) { $sql .= ' AND r.purok_id = :purok_id'; $params[':purok_id'] = $purokId; }
    if (!empty($gender)) { $sql .= ' AND COALESCE(r.gender,\'Other\') = :gender'; $params[':gender'] = $gender; }
    if ($voter === 'registered') { $sql .= " AND (r.voter_registered='Yes' OR LOWER(COALESCE(r.voter_status,''))='registered') "; }
    else if ($voter === 'not_registered') { $sql .= " AND (r.voter_registered='No' AND LOWER(COALESCE(r.voter_status,''))!='registered') "; }
    if ($voterOnly) { $sql .= " AND COALESCE(r.voter_status,'') <> '' "; }
    if (!empty($ageBucket)) {
      $sql .= ' AND (CASE WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) <= 17 THEN "0-17" '
           .  ' WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) BETWEEN 18 AND 35 THEN "18-35" '
           .  ' WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) BETWEEN 36 AND 59 THEN "36-59" '
           .  ' ELSE "60+" END) = :age_bucket ';
      $params[':age_bucket'] = $ageBucket;
    }
    $sql .= ' ORDER BY r.created_at DESC, r.id DESC LIMIT 500';
    $stmt = $pdo->prepare($sql);
    foreach ($params as $k=>$v) $stmt->bindValue($k, $v);
    $stmt->execute();
    echo json_encode(['ok'=>true,'data'=>$stmt->fetchAll()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Create
  if ($method === 'POST' && $action === 'create') {
    $in = body_json();
    $purok_id = (string)($in['purok_id'] ?? '');
    $scope = role_scope_purok(); if ($scope !== null) { $purok_id = $scope; }
    if ($purok_id==='') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'purok_id required'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    // validate purok exists to avoid FK error
    $chkP = $pdo->prepare('SELECT id FROM puroks WHERE id=:pid LIMIT 1');
    $chkP->execute([':pid'=>$purok_id]);
    if (!$chkP->fetchColumn()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid purok_id (not found): ' . $purok_id], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    // Accept split name fields and build full_name if not provided
    $last_name = trim($in['last_name'] ?? '');
    $first_name = trim($in['first_name'] ?? '');
    $middle_name = trim($in['middle_name'] ?? '');
    $full_name = trim($in['full_name'] ?? '');
    if ($full_name==='') {
      if ($last_name !== '' && $first_name !== '') {
        $full_name = $last_name . ', ' . $first_name . ($middle_name!=='' ? (' ' . $middle_name) : '');
      }
    }
    if ($full_name===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'full_name or name parts required'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    $gender = $in['gender'] ?? null;
    $birth_date = $in['birth_date'] ?? null;
    $occupation = $in['occupation'] ?? null;
    $civil_status = $in['civil_status'] ?? null;
    $address = $in['address'] ?? null;
    $contact_number = $in['contact_number'] ?? null;
    $email = $in['email'] ?? null;
    $educational_attainment = $in['educational_attainment'] ?? null;
    $religion = $in['religion'] ?? null;
    $citizenship = $in['citizenship'] ?? null;
    $blood_type = $in['blood_type'] ?? null;
    $remarks = $in['remarks'] ?? null;
    $age = isset($in['age']) && $in['age'] !== '' ? (int)$in['age'] : null;
    // DB uses ENUM('Yes','No') for voter_registered
    $voter_registered = isset($in['voter_registered']) ? (int)!!$in['voter_registered'] : null;
    $voter_status = $in['voter_status'] ?? null;
    $voter_registered_enum = ($voter_registered===null) ? null : ($voter_registered ? 'Yes' : 'No');
    $household_id = isset($in['household_id']) ? (string)$in['household_id'] : null;
    if ($household_id === '') { $household_id = null; }
    if ($household_id !== null) {
      $chkH = $pdo->prepare('SELECT id FROM households WHERE id=:hid LIMIT 1');
      $chkH->execute([':hid'=>$household_id]);
      if (!$chkH->fetchColumn()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid household_id (not found)'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    }

    $stmt = $pdo->prepare("INSERT INTO residents (
        purok_id, household_id, full_name, last_name, first_name, middle_name,
        gender, birth_date, age, occupation, civil_status, address, contact_number, email,
        educational_attainment, religion, citizenship, blood_type, remarks,
        voter_registered, voter_status, created_at)
      VALUES (
        :purok_id, :household_id, :full_name, :last_name, :first_name, :middle_name,
        :gender, :birth_date, :age, :occupation, :civil_status, :address, :contact_number, :email,
        :educational_attainment, :religion, :citizenship, :blood_type, :remarks,
        :vr, :vs, NOW())");
    $stmt->execute([
      ':purok_id'=>$purok_id,
      ':household_id'=>$household_id,
      ':full_name'=>$full_name,
      ':last_name'=>($last_name!==''?$last_name:null),
      ':first_name'=>($first_name!==''?$first_name:null),
      ':middle_name'=>($middle_name!==''?$middle_name:null),
      ':gender'=>$gender,
      ':birth_date'=>$birth_date,
      ':age'=>$age,
      ':occupation'=>$occupation,
      ':civil_status'=>$civil_status,
      ':address'=>$address,
      ':contact_number'=>$contact_number,
      ':email'=>$email,
      ':educational_attainment'=>$educational_attainment,
      ':religion'=>$religion,
      ':citizenship'=>$citizenship,
      ':blood_type'=>$blood_type,
      ':remarks'=>$remarks,
      ':vr'=>$voter_registered_enum,
      ':vs'=>$voter_status,
    ]);
    // For UUID default PK, lastInsertId may be empty; respond without id
    log_action('create','resident',null,['full_name'=>$full_name,'purok_id'=>$purok_id]);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Update
  if ($method === 'POST' && $action === 'update') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); if ($id===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    // scope check for purok leaders: ensure resident belongs to their purok
    $scope = role_scope_purok();
    if ($scope !== null) {
      $chk = $pdo->prepare('SELECT purok_id FROM residents WHERE id=:id'); $chk->execute([':id'=>$id]); $rid = $chk->fetchColumn();
      if ((string)$rid !== (string)$scope) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'Forbidden'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    }
    // Map voter_registered if provided
    if (array_key_exists('voter_registered',$in)) {
      $in['voter_registered'] = $in['voter_registered'] ? 'Yes' : 'No';
    }
    // Normalize empty household_id to null and validate if provided
    if (array_key_exists('household_id',$in) && $in['household_id'] === '') { $in['household_id'] = null; }
    if (array_key_exists('household_id',$in) && $in['household_id'] !== null) {
      $chkH = $pdo->prepare('SELECT id FROM households WHERE id=:hid LIMIT 1');
      $chkH->execute([':hid'=>$in['household_id']]);
      if (!$chkH->fetchColumn()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid household_id (not found)'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    }
    // If name parts provided and full_name omitted, reconstruct server-side
    if (!isset($in['full_name']) && (isset($in['last_name']) || isset($in['first_name']))) {
      $ln = trim((string)($in['last_name'] ?? ''));
      $fn = trim((string)($in['first_name'] ?? ''));
      $mn = trim((string)($in['middle_name'] ?? ''));
      if ($ln !== '' && $fn !== '') $in['full_name'] = $ln . ', ' . $fn . ($mn!==''?(' '.$mn):'');
    }
    $fields = [
      'full_name','last_name','first_name','middle_name','gender','birth_date','age','occupation',
      'civil_status','address','contact_number','email','educational_attainment','religion',
      'citizenship','blood_type','remarks','voter_registered','voter_status','household_id'
    ];
    $sets=[]; $params=[':id'=>$id];
    foreach($fields as $f){ if (array_key_exists($f,$in)) { $sets[] = "$f = :$f"; $params[":$f"] = $in[$f]; } }
    if (!$sets) { echo json_encode(['ok'=>true,'updated'=>0], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
    $sql = 'UPDATE residents SET '.implode(', ',$sets).' WHERE id=:id';
    $stmt = $pdo->prepare($sql); $stmt->execute($params);
    log_action('update','resident',$id,$in);
    echo json_encode(['ok'=>true,'updated'=>$stmt->rowCount()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  // Delete
  if ($method === 'POST' && $action === 'delete') {
    $in = body_json();
    $id = (string)($in['id'] ?? ''); if ($id===''){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id required']); exit; }
    $scope = role_scope_purok();
    if ($scope !== null) {
      $chk = $pdo->prepare('SELECT purok_id FROM residents WHERE id=:id'); $chk->execute([':id'=>$id]); $rid = $chk->fetchColumn();
      if ((string)$rid !== (string)$scope) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'Forbidden']); exit; }
    }
    $pdo->prepare('DELETE FROM residents WHERE id=:id')->execute([':id'=>$id]);
    log_action('delete','resident',$id,[]);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
  }

  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'Unsupported action'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
