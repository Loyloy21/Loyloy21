<?php
// Simple auth guard: include this at the top of protected pages
session_start();

function require_login(array $allowed_roles = []) {
  if (empty($_SESSION['logged_in'])) {
    header('Location: ../HTML/home/home.html');
    exit;
  }
  if ($allowed_roles && (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $allowed_roles, true))) {
    http_response_code(403);
    echo 'Access denied';
    exit;
  }
}
