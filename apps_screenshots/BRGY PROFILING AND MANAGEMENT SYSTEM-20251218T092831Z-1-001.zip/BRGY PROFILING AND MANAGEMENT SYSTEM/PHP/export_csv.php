<?php
require_once __DIR__ . '/db_config.php';
session_start();

try {
  $pdo = DB::pdo();

  // Build filters (same semantics as stats.php)
  $purokId = isset($_GET['purok_id']) && $_GET['purok_id'] !== '' ? $_GET['purok_id'] : null;
  if (isset($_SESSION['role']) && $_SESSION['role'] === 'purok' && !empty($_SESSION['purok_id'])) {
    // Enforce scope for purok leaders
    $purokId = $_SESSION['purok_id'];
  }
  $gender = isset($_GET['gender']) && $_GET['gender'] !== '' ? $_GET['gender'] : null;
  $ageBucket = isset($_GET['age_bucket']) && $_GET['age_bucket'] !== '' ? $_GET['age_bucket'] : null; // '0-17','18-35','36-59','60+'
  $voter = isset($_GET['voter']) && $_GET['voter'] !== '' ? strtolower($_GET['voter']) : null; // 'registered'|'not_registered'

  $where = ' WHERE 1=1 ';
  $params = [];
  if ($purokId) { $where .= ' AND r.purok_id = :purok_id '; $params[':purok_id'] = $purokId; }
  if ($gender) { $where .= ' AND COALESCE(r.gender,\'Other\') = :gender '; $params[':gender'] = $gender; }
  if ($voter === 'registered') {
    $where .= " AND (COALESCE(r.voter_registered,0)=1 OR LOWER(COALESCE(r.voter_status,''))='registered') ";
  } else if ($voter === 'not_registered') {
    $where .= " AND (COALESCE(r.voter_registered,0)=0 AND LOWER(COALESCE(r.voter_status,''))!='registered') ";
  }
  if ($ageBucket) {
    $where .= ' AND (CASE WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) <= 17 THEN \"0-17\" '
          .    ' WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) BETWEEN 18 AND 35 THEN \"18-35\" '
          .    ' WHEN COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) BETWEEN 36 AND 59 THEN \"36-59\" '
          .    ' ELSE \"60+\" END) = :age_bucket ';
    $params[':age_bucket'] = $ageBucket;
  }

  // Select a practical set of columns known from stats usage
  $sql = "SELECT r.id, r.purok_id, p.name AS purok_name, 
                 COALESCE(r.gender,'') AS gender,
                 COALESCE(r.age, TIMESTAMPDIFF(YEAR, r.birth_date, CURDATE())) AS age,
                 DATE_FORMAT(r.birth_date, '%Y-%m-%d') AS birth_date,
                 COALESCE(r.occupation,'') AS occupation,
                 COALESCE(r.voter_registered,0) AS voter_registered,
                 COALESCE(r.voter_status,'') AS voter_status,
                 DATE_FORMAT(r.created_at, '%Y-%m-%d %H:%i:%s') AS created_at
          FROM residents r
          LEFT JOIN puroks p ON p.id = r.purok_id
          $where
          ORDER BY p.name, r.id";
  $stmt = $pdo->prepare($sql);
  foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
  $stmt->execute();

  // Output CSV headers
  header('Content-Type: text/csv; charset=utf-8');
  header('Cache-Control: no-store');
  $fname = 'residents_export_' . date('Ymd_His') . '.csv';
  header('Content-Disposition: attachment; filename=' . $fname);

  $out = fopen('php://output', 'w');
  fputcsv($out, ['ID','Purok ID','Purok Name','Gender','Age','Birth Date','Occupation','Voter Registered','Voter Status','Created At']);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($out, [
      $row['id'],
      $row['purok_id'],
      $row['purok_name'],
      $row['gender'],
      $row['age'],
      $row['birth_date'],
      $row['occupation'],
      (int)$row['voter_registered'] ? 'Yes' : 'No',
      $row['voter_status'],
      $row['created_at'],
    ]);
  }
  fclose($out);
  exit;
} catch (Throwable $e) {
  http_response_code(500);
  header('Content-Type: application/json');
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
