// ==========================
// Login Validation with Lockout
// ==========================

const LOCK_KEY = "lockout_time";
const ATTEMPT_KEY = "login_attempts";
let lockTimer = null;

// Demo credentials
const accounts = {
  admin: { username: "admin", password: "admin123", redirect: "../admin/admin_dashboard.html" },
  staff: { username: "staff", password: "staff123", redirect: "../population/population_dashboard.html" },
  purok: { username: "purok", password: "purok123", redirect: "../purok/purok_dashboard.html" }
};

function handleLogin(role) {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  const attempt = parseInt(localStorage.getItem(ATTEMPT_KEY)) || 0;
  const lockoutTime = parseInt(localStorage.getItem(LOCK_KEY)) || 0;
  const now = Date.now();

  // Check if locked
  if (lockoutTime && now < lockoutTime) {
    const secondsLeft = Math.ceil((lockoutTime - now) / 1000);
    alert(`Account is temporarily locked. Please wait ${secondsLeft} seconds.`);
    return;
  }

  // Validate login
  const account = accounts[role];
  if (username === account.username && password === account.password) {
    alert("Login successful!");
    localStorage.removeItem(ATTEMPT_KEY);
    localStorage.removeItem(LOCK_KEY);
    window.location.href = account.redirect;
    return;
  }

  // Invalid attempt
  const newAttempt = attempt + 1;
  localStorage.setItem(ATTEMPT_KEY, newAttempt);

  if (newAttempt % 3 === 0) {
    const lockDuration = newAttempt === 3 ? 15000 : newAttempt === 6 ? 30000 : 60000;
    localStorage.setItem(LOCK_KEY, now + lockDuration);
    alert(`Too many failed attempts. Locked for ${lockDuration / 1000} seconds.`);
  } else {
    alert(`Invalid credentials. Attempt ${newAttempt}.`);
  }
}
