/**
 * Voters & Reports Module
 * Handles all voter-related functionality and reporting
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts when the page loads
    if (document.getElementById('voterDistributionChart') && document.getElementById('voterAgeChart')) {
        initializeCharts();
    }

    // Event listeners
    document.getElementById('generateReport')?.addEventListener('click', generateVoterReport);
    document.getElementById('exportVoterData')?.addEventListener('click', exportVoterData);
    
    // Load initial data
    loadVoterStatistics();
    generateVoterReport();
});

// Chart instances
let voterDistributionChart, voterAgeChart;

/**
 * Initialize all charts
 */
function initializeCharts() {
    // Voter Distribution by Purok Chart
    const voterDistCtx = document.getElementById('voterDistributionChart').getContext('2d');
    voterDistributionChart = new Chart(voterDistCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Voters',
                data: [],
                backgroundColor: 'rgba(59, 130, 246, 0.7)',
                borderColor: 'rgba(59, 130, 246, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.parsed.y} voters`;
                        }
                    }
                }
            }
        }
    });

    // Voter Age Distribution Chart
    const ageDistCtx = document.getElementById('voterAgeChart').getContext('2d');
    voterAgeChart = new Chart(ageDistCtx, {
        type: 'doughnut',
        data: {
            labels: ['18-25', '26-35', '36-45', '46-55', '56-65', '65+'],
            datasets: [{
                data: [0, 0, 0, 0, 0, 0],
                backgroundColor: [
                    'rgba(59, 130, 246, 0.7)',
                    'rgba(16, 185, 129, 0.7)',
                    'rgba(245, 158, 11, 0.7)',
                    'rgba(139, 92, 246, 0.7)',
                    'rgba(236, 72, 153, 0.7)',
                    'rgba(239, 68, 68, 0.7)'
                ],
                borderColor: [
                    'rgba(59, 130, 246, 1)',
                    'rgba(16, 185, 129, 1)',
                    'rgba(245, 158, 11, 1)',
                    'rgba(139, 92, 246, 1)',
                    'rgba(236, 72, 153, 1)',
                    'rgba(239, 68, 68, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const value = context.raw;
                            const percentage = Math.round((value / total) * 100);
                            return `${context.label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Load voter statistics
 */
async function loadVoterStatistics() {
    try {
        const response = await fetch('../../PHP/voters.php?action=getStatistics');
        const data = await response.json();
        
        if (data.success) {
            // Update statistics cards
            document.getElementById('totalVoters').textContent = data.totalVoters || 0;
            document.getElementById('maleVoters').textContent = data.maleVoters || 0;
            document.getElementById('femaleVoters').textContent = data.femaleVoters || 0;
            document.getElementById('nonVoters').textContent = data.nonVoters || 0;
            
            // Update voter distribution chart
            if (voterDistributionChart) {
                voterDistributionChart.data.labels = data.purokDistribution?.map(item => item.purok_name) || [];
                voterDistributionChart.data.datasets[0].data = data.purokDistribution?.map(item => item.voter_count) || [];
                voterDistributionChart.update();
            }
            
            // Update age distribution chart
            if (voterAgeChart && data.ageDistribution) {
                const ageData = [0, 0, 0, 0, 0, 0];
                data.ageDistribution.forEach(item => {
                    const age = parseInt(item.age);
                    if (age >= 18 && age <= 25) ageData[0] += item.count;
                    else if (age <= 35) ageData[1] += item.count;
                    else if (age <= 45) ageData[2] += item.count;
                    else if (age <= 55) ageData[3] += item.count;
                    else if (age <= 65) ageData[4] += item.count;
                    else ageData[5] += item.count;
                });
                voterAgeChart.data.datasets[0].data = ageData;
                voterAgeChart.update();
            }
        } else {
            console.error('Failed to load voter statistics:', data.message);
            alert('Failed to load voter statistics. Please try again.');
        }
    } catch (error) {
        console.error('Error loading voter statistics:', error);
        alert('An error occurred while loading voter statistics.');
    }
}

/**
 * Generate voter registration report
 */
async function generateVoterReport() {
    const year = document.getElementById('reportYear')?.value || new Date().getFullYear();
    const tbody = document.getElementById('voterReportBody');
    
    if (!tbody) return;
    
    try {
        // Show loading state
        tbody.innerHTML = '<tr><td colspan="5" class="text-center">Loading...</td></tr>';
        
        // Fetch report data
        const response = await fetch(`../../PHP/voters.php?action=getRegistrationReport&year=${year}`);
        const data = await response.json();
        
        if (data.success && Array.isArray(data.report)) {
            // Clear loading state
            tbody.innerHTML = '';
            
            // Populate table
            data.report.forEach(monthData => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${monthData.month}</td>
                    <td>${monthData.new_voters || 0}</td>
                    <td>${monthData.male || 0}</td>
                    <td>${monthData.female || 0}</td>
                    <td><strong>${monthData.total || 0}</strong></td>
                `;
                tbody.appendChild(row);
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">No data available</td></tr>';
            if (!data.success) {
                console.error('Failed to generate report:', data.message);
            }
        }
    } catch (error) {
        console.error('Error generating report:', error);
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-error">Error loading report</td></tr>';
    }
}

/**
 * Export voter data
 */
async function exportVoterData() {
    try {
        // Show loading state
        const exportBtn = document.getElementById('exportVoterData');
        const originalText = exportBtn.innerHTML;
        exportBtn.disabled = true;
        exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Exporting...';
        
        // Fetch export data
        const response = await fetch('../../PHP/voters.php?action=exportData');
        const blob = await response.blob();
        
        // Create download link
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `voter-data-${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(a);
        a.click();
        
        // Clean up
        window.URL.revokeObjectURL(url);
        a.remove();
        
        // Reset button state
        exportBtn.disabled = false;
        exportBtn.innerHTML = originalText;
    } catch (error) {
        console.error('Error exporting data:', error);
        alert('Failed to export data. Please try again.');
        
        // Reset button state on error
        const exportBtn = document.getElementById('exportVoterData');
        if (exportBtn) {
            exportBtn.disabled = false;
            exportBtn.innerHTML = '<i class="fas fa-download"></i> Export Data';
        }
    }
}

// Make functions available globally if needed
window.votersModule = {
    loadVoterStatistics,
    generateVoterReport,
    exportVoterData
};
