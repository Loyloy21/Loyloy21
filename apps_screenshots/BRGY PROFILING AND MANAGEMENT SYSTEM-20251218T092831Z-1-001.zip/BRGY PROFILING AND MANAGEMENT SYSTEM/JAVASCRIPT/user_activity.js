(function(){
  function $(sel){ return document.querySelector(sel); }
  function $all(sel){ return Array.from(document.querySelectorAll(sel)); }
  function fmtDateTime(s){ try{ const d=new Date(s); return d.toLocaleString(); }catch(e){ return s||'—'; } }
  function text(v){ return (v===null||v===undefined||v==='') ? '—' : String(v); }

  async function loadUsers(){
    const tbody = $('#userTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="7">Loading...</td></tr>';
    try{
      const res = await fetch('../../PHP/users_admin.php?action=list', {cache:'no-store', credentials:'same-origin'});
      const raw = await res.text();
      let json; try { json = JSON.parse(raw); } catch(parseErr){
        throw new Error(`Unexpected response (${res.status}): ${raw.slice(0,200)}`);
      }
      if (!json || json.ok !== true || !Array.isArray(json.data)) throw new Error(json && json.error || 'Failed');
      if (json.data.length === 0){ tbody.innerHTML = '<tr><td colspan="7">No users found</td></tr>'; return; }
      const rows = json.data.map(u => {
        return `<tr>
          <td>${text(u.id)}</td>
          <td>${text(u.username)}</td>
          <td>${text(u.full_name)}</td>
          <td>${text(u.role)}</td>
          <td>${text(u.status)}</td>
          <td>${text(u.purok_id)}</td>
          <td>${fmtDateTime(u.created_at)}</td>
        </tr>`;
      }).join('');
      tbody.innerHTML = rows;
    } catch(e){
      tbody.innerHTML = `<tr><td colspan="7" style="color:#b91c1c;">Failed to load users: ${text(e.message)}</td></tr>`;
      console.error('loadUsers:', e);
    }
  }

  async function loadActivity(){
    const tbody = $('#activityTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="5">Loading...</td></tr>';
    try{
      const res = await fetch('../../PHP/activity_feed.php?limit=50', {cache:'no-store', credentials:'same-origin'});
      const raw = await res.text();
      let json; try { json = JSON.parse(raw); } catch(parseErr){
        throw new Error(`Unexpected response (${res.status}): ${raw.slice(0,200)}`);
      }
      if (!json || json.ok !== true || !Array.isArray(json.data)) throw new Error(json && json.error || 'Failed');
      if (json.data.length === 0){ tbody.innerHTML = '<tr><td colspan="5">No activity yet</td></tr>'; return; }
      const rows = json.data.map(a => {
        const details = typeof a.details === 'object' && a.details !== null ? JSON.stringify(a.details) : text(a.details);
        return `<tr>
          <td>${fmtDateTime(a.created_at)}</td>
          <td>${text(a.username)}</td>
          <td>${text(a.action_type)}</td>
          <td>${text(a.entity)}${a.entity_id?(' #'+a.entity_id):''}</td>
          <td title="${details.replace(/&/g,'&amp;').replace(/</g,'&lt;')}">${details.length>80?details.slice(0,80)+'…':details}</td>
        </tr>`;
      }).join('');
      tbody.innerHTML = rows;
    } catch(e){
      tbody.innerHTML = `<tr><td colspan=\"5\" style=\"color:#b91c1c;\">Failed to load activity logs: ${text(e.message)}</td></tr>`;
      console.error('loadActivity:', e);
    }
  }

  // Hook into nav clicks to lazy-load when section is shown
  document.addEventListener('DOMContentLoaded', function(){
    const navUsers = document.querySelector('a[data-target="sec-users"]');
    const navAct = document.querySelector('a[data-target="sec-activity"]');
    if (navUsers) navUsers.addEventListener('click', () => setTimeout(loadUsers, 50));
    if (navAct) navAct.addEventListener('click', () => setTimeout(loadActivity, 50));

    // If sections are already visible (direct load), populate
    const secUsers = $('#sec-users');
    const secAct = $('#sec-activity');
    if (secUsers && secUsers.style.display !== 'none') loadUsers();
    if (secAct && secAct.style.display !== 'none') loadActivity();
  });

  // Expose for manual refresh
  window.AdminTables = { loadUsers, loadActivity };
})();
