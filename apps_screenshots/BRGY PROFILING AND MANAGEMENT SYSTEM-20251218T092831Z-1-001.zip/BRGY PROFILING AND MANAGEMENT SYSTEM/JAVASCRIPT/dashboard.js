// Dashboard charts with live data (fallbacks to sample)
(function(){
  const ready = (fn)=> document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn);
  const sample = {
    purok_population: { labels: ['Purok 1','Purok 2','Purok 3','Purok 4','Purok 5'], data: [820,650,740,590,420] },
    gender: { labels: ['Male','Female','Other'], data: [51,47,2] },
    age_groups: { labels: ['0-17','18-35','36-59','60+'], data: [1120,1850,1420,430] }
  };

  let charts = {};

  if (typeof Chart !== 'undefined' && typeof ChartDataLabels !== 'undefined' && Chart.register) { Chart.register(ChartDataLabels); }

  function ensureChart(id, config){
    const el = document.getElementById(id);
    if (!el || typeof Chart === 'undefined') return null;
    if (charts[id]) return charts[id];
    charts[id] = new Chart(el.getContext('2d'), config);
    return charts[id];
  }

  function render(data){
    const pp = data.purok_population || sample.purok_population;
    const gen = data.gender || sample.gender;
    const age = data.age_groups || sample.age_groups;
    // update summary cards if present
    try{
      const set = (id,v)=>{ const el = document.getElementById(id); if (el) el.textContent = v; };
      if (data.totals){
        const t = data.totals;
        set('totalResidents', t.residents);
        set('totalHouseholds', t.households);
        set('activeUsers', t.active_users);
        // simple household occupancy (avg residents per household)
        if (t.residents != null && t.households){
          const occ = t.households ? (t.residents / t.households) : 0;
          set('householdOccupancy', (isFinite(occ) && occ>0) ? occ.toFixed(1) : '—');
        }
      }
      // gender breakdown cards
      if (gen && Array.isArray(gen.labels) && Array.isArray(gen.data)){
        gen.labels.forEach((label, idx)=>{
          const val = gen.data[idx] ?? 0;
          const l = (label||'').toString().toLowerCase();
          if (l === 'male') set('totalMale', val);
          else if (l === 'female') set('totalFemale', val);
          else set('totalOther', (gen.data[idx] ?? 0));
        });
      }
      // age group cards
      if (age && Array.isArray(age.labels) && Array.isArray(age.data)){
        age.labels.forEach((label, idx)=>{
          const v = (label||'').toString();
          const val = age.data[idx] ?? 0;
          if (v === '0-17') set('count0_17', val);
          else if (v === '18-35') set('count18_35', val);
          else if (v === '36-59') set('count36_59', val);
          else if (v === '60+') set('count60p', val);
        });
      }
      // voters registered/not cards
      if (data.voters && Array.isArray(data.voters.labels) && Array.isArray(data.voters.data)){
        data.voters.labels.forEach((label, idx)=>{
          const v = (label||'').toString().toLowerCase();
          const val = data.voters.data[idx] ?? 0;
          if (v.includes('registered') && !v.includes('not')) set('votersRegistered', val);
          if (v.includes('not')) set('votersNotRegistered', val);
        });
      }
    }catch(_){/* no-op */}

    const bar = ensureChart('chartPurokPopulation', {
      type: 'bar',
      data: { labels: pp.labels, datasets: [{ label: 'Residents per Purok', data: pp.data, backgroundColor: 'rgba(124, 58, 237, 0.7)'}] },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true, position: 'bottom' },
          title: { display: true, text: 'Purok Population', font: { weight: '600', size: 14 } },
          tooltip:{ callbacks:{ label: (ctx)=> `${ctx.dataset.label}: ${ctx.parsed.y}` } },
          datalabels: { anchor: 'end', align: 'top', formatter: (v)=> v, color: '#111827', font:{ size: 10 } }
        },
        scales: {
          x: { title: { display: true, text: 'Purok' } },
          y: { title: { display: true, text: 'Residents' }, beginAtZero: true }
        }
      }
    });
    if (bar) { bar.data.labels = pp.labels; bar.data.datasets[0].data = pp.data; bar.update(); }

    const dough = ensureChart('chartGender', {
      type: 'doughnut',
      data: { labels: gen.labels, datasets: [{ data: gen.data, backgroundColor: ['#8b5cf6','#22d3ee','#34d399'] }] },
      options: {
        responsive: true,
        plugins:{
          legend:{ display:true, position:'bottom' },
          title:{ display:true, text:'Gender Distribution', font:{ weight:'600', size:14 } },
          tooltip:{ callbacks:{ label: (ctx)=> `${ctx.label}: ${ctx.parsed}` } },
          datalabels:{ formatter:(v,ctx)=>{
            const total = ctx.chart.data.datasets[0].data.reduce((a,b)=>a+b,0)||0;
            const pct = total? ((v/total)*100).toFixed(1)+'%':'0%';
            return pct;
          }, color:'#111827', font:{ size:10 } }
        }
      }
    });
    if (dough) { dough.data.labels = gen.labels; dough.data.datasets[0].data = gen.data; dough.update(); }

    const friendlyAgeLabels = age.labels.map((lbl)=>{
      const v = (lbl||'').toString();
      if (v === '0-17') return 'Kids';
      if (v === '18-35') return 'Teens';
      if (v === '36-59') return 'Adult';
      if (v === '60+') return 'Senior Citizens';
      return v;
    });

    const line = ensureChart('chartAge', {
      type: 'line',
      data: { labels: friendlyAgeLabels, datasets: [{ label: 'Residents', data: age.data, borderColor: '#8b5cf6', backgroundColor: 'rgba(139,92,246,0.25)', fill: true, tension: 0.3 }] },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true, position: 'bottom' },
          title: { display: true, text: 'Residents by Age Group', font: { weight:'600', size:14 } },
          tooltip:{ callbacks:{ label: (ctx)=> `${ctx.dataset.label}: ${ctx.parsed.y}` } },
          datalabels: { anchor: 'end', align: 'top', formatter: (v)=> v, color:'#111827', font:{ size:10 } }
        },
        scales: {
          x: { title: { display: true, text: 'Age Group' } },
          y: { title: { display: true, text: 'Residents' }, beginAtZero: true }
        }
      }
    });
    if (line) { line.data.labels = friendlyAgeLabels; line.data.datasets[0].data = age.data; line.update(); }

    // Voters registered vs not
    if (data.voters) {
      const voters = data.voters;
      const baseConfig = {
        type: 'pie',
        data: { labels: voters.labels, datasets: [{ data: voters.data, backgroundColor: ['#34d399','#f87171'] }] },
        options: {
          responsive: true,
          plugins:{
            legend:{ display:true, position:'bottom' },
            title:{ display:true, text:'Voter Registration Status', font:{ weight:'600', size:14 } },
            tooltip:{ callbacks:{ label: (ctx)=> `${ctx.label}: ${ctx.parsed}` } },
            datalabels:{ formatter:(v,ctx)=>{
              const total = ctx.chart.data.datasets[0].data.reduce((a,b)=>a+b,0)||0;
              const pct = total? ((v/total)*100).toFixed(1)+'%':'0%';
              return pct;
            }, color:'#111827', font:{ size:10 } }
          }
        }
      };
      const votersChart = ensureChart('chartVoters', baseConfig);
      if (votersChart) {
        votersChart.data.labels = voters.labels;
        votersChart.data.datasets[0].data = voters.data;
        votersChart.update();
      }
      const votersPurokChart = ensureChart('chartVotersPurok', baseConfig);
      if (votersPurokChart) {
        votersPurokChart.data.labels = voters.labels;
        votersPurokChart.data.datasets[0].data = voters.data;
        votersPurokChart.update();
      }
    }

    // Occupation top 5
    if (data.occupation) {
      const occ = data.occupation;
      const occChart = ensureChart('chartOccupation', {
        type: 'bar',
        data: { labels: occ.labels, datasets: [{ label: 'Residents', data: occ.data, backgroundColor: 'rgba(34,211,238,0.7)' }] },
        options: {
          responsive: true,
          plugins: {
            legend: { display: true, position: 'bottom' },
            title: { display: true, text: 'Top Occupations', font:{ weight:'600', size:14 } },
            tooltip:{ callbacks:{ label: (ctx)=> `${ctx.dataset.label}: ${ctx.parsed.y}` } },
            datalabels:{ anchor:'end', align:'top', formatter:(v)=> v, color:'#111827', font:{ size:10 } }
          },
          scales: {
            x: { title: { display: true, text: 'Occupation' } },
            y: { title: { display: true, text: 'Residents' }, beginAtZero: true }
          }
        }
      });
      if (occChart) { occChart.data.labels = occ.labels; occChart.data.datasets[0].data = occ.data; occChart.update(); }
    }

    // Daily added (last 7 days)
    if (data.daily_added) {
      const d = data.daily_added;
      const dailyChart = ensureChart('chartDaily', {
        type: 'line',
        data: { labels: d.labels, datasets: [{ label: 'Residents Added', data: d.data, borderColor: '#22d3ee', backgroundColor: 'rgba(34,211,238,0.25)', fill: true, tension: 0.3 }] },
        options: {
          responsive: true,
          plugins: {
            legend: { display: true, position: 'bottom' },
            title: { display: true, text: 'Residents Added (Last 7 Days)', font:{ weight:'600', size:14 } },
            tooltip:{ callbacks:{ label: (ctx)=> `${ctx.dataset.label}: ${ctx.parsed.y}` } },
            datalabels:{ anchor:'end', align:'top', formatter:(v)=> v, color:'#111827', font:{ size:10 } }
          },
          scales: {
            x: { title: { display: true, text: 'Date' } },
            y: { title: { display: true, text: 'Residents Added' }, beginAtZero: true }
          }
        }
      });
      if (dailyChart) { dailyChart.data.labels = d.labels; dailyChart.data.datasets[0].data = d.data; dailyChart.update(); }
    }
  }

  async function fetchStats(params){
    const q = params ? ('?' + new URLSearchParams(params)) : '';
    try {
      const res = await fetch('../../PHP/stats.php' + q, { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'Unknown');
      render(json);
    } catch (e) {
      render(sample);
    }
  }

  ready(()=> fetchStats());
  // expose for other scripts (population page)
  window.BrgyDashboard = { fetchStats, render };
})();
