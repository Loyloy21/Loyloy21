(function(){
  function $(s){ return document.querySelector(s); }
  function text(v){ return (v===null||v===undefined||v==='') ? '' : String(v); }

  async function loadProfile(){
    try{
      const res = await fetch('../../PHP/users_profile.php?action=me', {cache:'no-store', credentials:'same-origin'});
      const raw = await res.text();
      let json; try{ json = JSON.parse(raw); }catch(e){ throw new Error(`Unexpected response (${res.status})`); }
      if (!json.ok || !json.data) throw new Error(json.error || 'Failed to load profile');
      const u = json.data;
      $('#set_username').value = text(u.username);
      $('#set_full_name').value = text(u.full_name);
      $('#set_role').value = text(u.role);
    } catch(err){ console.error('loadProfile:', err); }
  }

  async function onProfileSubmit(e){
    e.preventDefault();
    const full_name = $('#set_full_name').value.trim();
    if (!full_name){ alert('Full Name is required'); return; }
    try{
      const res = await fetch('../../PHP/users_profile.php?action=update', {
        method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ full_name })
      });
      const raw = await res.text();
      let json; try{ json = JSON.parse(raw); }catch(e){ throw new Error(`Unexpected response (${res.status})`); }
      if (!json.ok) throw new Error(json.error||'Failed to update profile');
      alert('Profile updated');
    } catch(err){ alert(err.message); }
  }

  async function onPasswordSubmit(e){
    e.preventDefault();
    const cur = $('#set_current_password').value;
    const npw = $('#set_new_password').value;
    const cfm = $('#set_confirm_password').value;
    if (!cur || !npw){ alert('Please fill passwords'); return; }
    if (npw !== cfm){ alert('New password and confirmation do not match'); return; }
    try{
      const res = await fetch('../../PHP/users_profile.php?action=change_password', {
        method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ current_password: cur, new_password: npw })
      });
      const raw = await res.text();
      let json; try{ json = JSON.parse(raw); }catch(e){ throw new Error(`Unexpected response (${res.status})`); }
      if (!json.ok) throw new Error(json.error||'Failed to change password');
      $('#set_current_password').value=''; $('#set_new_password').value=''; $('#set_confirm_password').value='';
      alert('Password changed successfully');
    } catch(err){ alert(err.message); }
  }

  document.addEventListener('DOMContentLoaded', function(){
    const nav = document.querySelector('a[data-target="sec-settings"]');
    if (nav) nav.addEventListener('click', () => setTimeout(loadProfile, 50));
    const sec = $('#sec-settings'); if (sec && sec.style.display!=='none') loadProfile();
    const pf = $('#profileForm'); if (pf) pf.addEventListener('submit', onProfileSubmit);
    const ps = $('#passwordForm'); if (ps) ps.addEventListener('submit', onPasswordSubmit);
  });
})();
