(function(){
  const ready = (fn)=> document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn);
  ready(()=>{
    // responsive nav
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');
    if (navToggle && navLinks) navToggle.addEventListener('click', ()=> navLinks.classList.toggle('open'));

    // info vs login section swapping in the same position (bottom-right area)
    const loginBtn = document.getElementById('loginBtn');
    const closeLogin = document.getElementById('closeLogin');
    const infoSection = document.querySelector('.info-section');
    const loginSection = document.getElementById('loginSection');
    const authSection = document.getElementById('authSection');
    const authTitle = document.getElementById('authTitle');
    const authSubmit = document.getElementById('authSubmit');

    function showLogin(e){
      if (e) e.preventDefault();
      if (infoSection) infoSection.style.display = 'none';
      if (loginSection) {
        loginSection.style.display = 'block';
        loginSection.setAttribute('aria-hidden','false');
      }
    }
    function hideLogin(e){
      if (e) e.preventDefault();
      if (loginSection) {
        loginSection.style.display = 'none';
        loginSection.setAttribute('aria-hidden','true');
      }
      if (infoSection) infoSection.style.display = 'flex';
    }

    if (loginBtn) loginBtn.addEventListener('click', showLogin);
    if (closeLogin) closeLogin.addEventListener('click', hideLogin);

    // initialize: keep login hidden, info visible
    if (loginSection) loginSection.style.display = 'none';
    if (authSection) authSection.style.display = 'none';

    // portal selection -> navigate to dedicated login pages (keeps shared design there)
    document.querySelectorAll('.portal-btn').forEach(btn=>{
      btn.addEventListener('click', (e)=>{
        e.preventDefault();
        const portal = btn.getAttribute('data-portal');
        let targetHref = '../admin/admin_login.html';
        if (portal === 'staff') targetHref = '../staff/staff_login.html';
        if (portal === 'resident') targetHref = '../purok/purok_login.html';
        window.location.href = targetHref;
      });
    });

    // back button logic is unused now but kept harmless if present
  });
})();
