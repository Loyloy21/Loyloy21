(function(){
  const ready = (fn)=> document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn);
  ready(()=>{
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');
    if (navToggle && navLinks) navToggle.addEventListener('click', ()=> navLinks.classList.toggle('open'));
  });
})();
