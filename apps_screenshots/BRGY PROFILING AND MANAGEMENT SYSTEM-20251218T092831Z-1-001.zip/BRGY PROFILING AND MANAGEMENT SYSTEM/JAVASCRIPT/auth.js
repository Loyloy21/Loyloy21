(function(){
  const ready = (fn)=> document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn);
  ready(()=>{
    function resolveEndpoint(){
      try {
        const origin = window.location.origin;
        const path = window.location.pathname; // e.g., /BRGY PROFILING AND MANAGEMENT SYSTEM/HTML/admin/admin_login.html
        const marker = '/BRGY PROFILING AND MANAGEMENT SYSTEM/';
        const idx = path.indexOf(marker);
        if (idx !== -1) {
          const root = path.substring(0, idx + marker.length - 1); // "/BRGY PROFILING AND MANAGEMENT SYSTEM"
          // Encode spaces for safety
          const safeRoot = root.replace(/ /g, '%20');
          return origin + safeRoot + '/PHP/auth_login.php';
        }
        // Fallback to absolute from web root (Apache docroot)
        return origin + '/BRGY%20PROFILING%20AND%20MANAGEMENT%20SYSTEM/PHP/auth_login.php';
      } catch(e) {
        return '../../PHP/auth_login.php';
      }
    }
    const endpoint = resolveEndpoint();
    try { console.debug('[auth] login endpoint:', endpoint); } catch(_){ }

    document.querySelectorAll('form.login-form').forEach(form=>{
      form.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const username = (form.querySelector('input[name="username"]')||{}).value || '';
        const password = (form.querySelector('input[name="password"]')||{}).value || '';
        const role = form.getAttribute('data-role') || ((form.querySelector('input[name="role"]')||{}).value || '');
        if (!username || !password || !role) {
          alert('Please enter username, password, and ensure role is set.');
          return;
        }
        try {
          const res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password, role })
          });
          let data = null; let parseErr = null;
          try { data = await res.json(); } catch(e){ parseErr = e; }
          if (!res.ok) {
            const msg = (data && (data.error || JSON.stringify(data))) || `HTTP ${res.status}`;
            alert(`Login failed: ${msg}`);
            try { console.error('[auth] login failed status', res.status, 'body:', data); } catch(_){ }
            return;
          }
          if (!data || !data.ok) {
            const msg = (data && data.error) || (parseErr ? 'Invalid server response' : 'Login failed');
            alert(msg);
            try { console.error('[auth] login response not ok', data); } catch(_){ }
            return;
          }
          window.location.href = data.redirect || '../home/home.html';
        } catch (err) {
          alert('Network error. Please try again.');
          try { console.error('[auth] network error', err); } catch(_){ }
        }
      });
    });
  });
})();
