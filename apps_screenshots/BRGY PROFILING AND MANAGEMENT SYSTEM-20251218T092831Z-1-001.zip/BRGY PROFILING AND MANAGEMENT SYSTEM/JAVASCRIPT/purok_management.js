(function(){
  function $(s){ return document.querySelector(s); }
  function text(v){ return (v===null||v===undefined||v==='') ? '—' : String(v); }
  function fmtDateTime(s){ try{ return new Date(s).toLocaleString(); } catch(e){ return s||'—'; } }

  async function loadPuroks(){
    const tbody = $('#purokTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="5">Loading...</td></tr>';
    try{
      const res = await fetch('../../PHP/purok_admin.php?action=list', {cache:'no-store', credentials:'same-origin'});
      const raw = await res.text();
      let json; try { json = JSON.parse(raw); } catch(e){ throw new Error(`Unexpected response (${res.status}): ${raw.slice(0,200)}`); }
      if (!json.ok || !Array.isArray(json.data)) throw new Error(json.error || 'Failed');
      if (json.data.length === 0){ tbody.innerHTML = '<tr><td colspan="5">No puroks yet</td></tr>'; return; }
      tbody.innerHTML = json.data.map(p => `
        <tr>
          <td>${text(p.id)}</td>
          <td>
            <span class="pname" data-id="${p.id}">${text(p.name)}</span>
          </td>
          <td>${text(p.resident_count)}</td>
          <td>${fmtDateTime(p.created_at)}</td>
          <td>
            <button class="btn btn-sm rename" data-id="${p.id}">Rename</button>
            <button class="btn btn-sm btn-secondary delete" data-id="${p.id}">Delete</button>
          </td>
        </tr>
      `).join('');

      // bind buttons
      tbody.querySelectorAll('button.rename').forEach(btn => btn.addEventListener('click', onRename));
      tbody.querySelectorAll('button.delete').forEach(btn => btn.addEventListener('click', onDelete));
    } catch(err){
      tbody.innerHTML = `<tr><td colspan="5" style="color:#b91c1c;">Failed to load puroks: ${text(err.message)}</td></tr>`;
      console.error('loadPuroks:', err);
    }
  }

  async function addPurok(){
    const input = $('#purokNameInput');
    const name = input && input.value ? input.value.trim() : '';
    if (!name) { alert('Please enter a purok name'); return; }
    try{
      const res = await fetch('../../PHP/purok_admin.php?action=create', {
        method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ name })
      });
      const raw = await res.text();
      let json; try{ json = JSON.parse(raw); } catch(e){ throw new Error(`Unexpected response (${res.status}): ${raw.slice(0,200)}`); }
      if (!json.ok) throw new Error(json.error||'Failed to add purok');
      input.value = '';
      await loadPuroks();
    } catch(err){ alert(err.message); }
  }

  async function onRename(ev){
    const id = ev.currentTarget.getAttribute('data-id');
    const current = ev.currentTarget.closest('tr').querySelector('.pname').textContent.trim();
    const name = prompt('Enter new purok name', current);
    if (!name || name.trim()===current) return;
    try{
      const res = await fetch('../../PHP/purok_admin.php?action=rename', {
        method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ id, name: name.trim() })
      });
      const raw = await res.text();
      let json; try{ json = JSON.parse(raw); } catch(e){ throw new Error(`Unexpected response (${res.status}): ${raw.slice(0,200)}`); }
      if (!json.ok) throw new Error(json.error||'Failed to rename purok');
      await loadPuroks();
    } catch(err){ alert(err.message); }
  }

  async function onDelete(ev){
    const id = ev.currentTarget.getAttribute('data-id');
    if (!confirm('Delete this purok? This cannot be undone.')) return;
    try{
      const res = await fetch('../../PHP/purok_admin.php?action=delete', {
        method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ id })
      });
      const raw = await res.text();
      let json; try{ json = JSON.parse(raw); } catch(e){ throw new Error(`Unexpected response (${res.status}): ${raw.slice(0,200)}`); }
      if (!json.ok) throw new Error(json.error||'Failed to delete purok');
      await loadPuroks();
    } catch(err){ alert(err.message); }
  }

  document.addEventListener('DOMContentLoaded', function(){
    const navP = document.querySelector('a[data-target="sec-puroks"]');
    if (navP) navP.addEventListener('click', () => setTimeout(loadPuroks, 50));
    const addBtn = $('#addPurokBtn');
    if (addBtn) addBtn.addEventListener('click', addPurok);

    const sec = $('#sec-puroks');
    if (sec && sec.style.display !== 'none') loadPuroks();
  });

  window.PurokAdmin = { loadPuroks };
})();
