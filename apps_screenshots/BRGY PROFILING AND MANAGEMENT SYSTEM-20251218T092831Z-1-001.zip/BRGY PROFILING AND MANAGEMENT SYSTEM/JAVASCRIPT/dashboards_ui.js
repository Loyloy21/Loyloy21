(function(){
  const ready = (fn)=> document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn);
  function qs(s,root=document){ return root.querySelector(s); }
  function qsa(s,root=document){ return Array.from(root.querySelectorAll(s)); }
  function showSection(id){
    qsa('[data-section]').forEach(sec=>{ sec.style.display = (sec.getAttribute('data-section')===id)?'block':'none'; });
    qsa('.nav a[data-target]').forEach(a=>{ a.classList.toggle('active', a.getAttribute('data-target')===id); });
  }
  async function jsonFetch(url, opts){
    const res = await fetch(url, opts||{cache:'no-store'});
    const txt = await res.text();
    let data = null;
    try {
      const trimmed = txt.trimStart();
      // try normal parse first
      data = JSON.parse(trimmed);
    } catch(e1){
      try {
        // try to recover if there are stray chars/BOM or notices before JSON
        const i = txt.indexOf('{');
        if (i >= 0) data = JSON.parse(txt.slice(i));
      } catch(e2){
        // if HTML returned (e.g., login page), hint clearly
        const ct = (res.headers.get('content-type')||'').toLowerCase();
        if (ct.includes('text/html')) {
          data = { ok:false, error:'Session expired or HTML response from server', _raw: txt };
        } else {
          data = { ok:false, error:'Invalid JSON', _raw: txt };
        }
      }
    }
    if (!res.ok || (data && data.ok===false)) {
      // helpful for debugging in console
      if (data && data._raw) { try { console.warn('jsonFetch raw response from', url, data._raw.slice(0,300)); } catch(_){} }
      throw new Error((data && data.error) || ('HTTP '+res.status));
    }
    return data;
  }

  function bindNav(){
    qsa('.nav a[data-target]').forEach(a=>{
      a.addEventListener('click', (e)=>{
        e.preventDefault();
        const target = a.getAttribute('data-target');
        showSection(target);
        // More Details panel should only be visible on dashboard overview
        const details = document.getElementById('detailsPanel');
        if (details && target !== 'sec-overview'){
          details.style.display = 'none';
        }
        // Special handling for Purok Voters Status nav
        if (a.hasAttribute('data-voters-nav') && target === 'sec-residents'){
          const addCard = document.querySelector('#sec-residents [data-add-resident-card]');
          if (addCard) addCard.style.display = 'none';
          const chartWrap = document.getElementById('purokVotersChartWrap');
          if (chartWrap) chartWrap.style.display = 'block';
          const voterSel = document.getElementById('purokVoterFilter');
          if (voterSel){
            voterSel.value = 'registered';
            voterSel.dispatchEvent(new Event('change'));
          }
          const heading = document.getElementById('purokResidentsHeading');
          if (heading) heading.style.display = 'none';
        } else if (target === 'sec-residents') {
          // Normal Residents nav: keep add form hidden and hide voters-only extras
          const addCard = document.querySelector('#sec-residents [data-add-resident-card]');
          if (addCard) addCard.style.display = 'none';
          const chartWrap = document.getElementById('purokVotersChartWrap');
          if (chartWrap) chartWrap.style.display = 'none';
          const voterSel = document.getElementById('purokVoterFilter');
          if (voterSel){
            voterSel.value = '';
            voterSel.dispatchEvent(new Event('change'));
          }
          const heading = document.getElementById('purokResidentsHeading');
          if (heading) heading.style.display = '';
        }
      });
    });
  }

  // Residents UI (list/add/delete)
  async function loadResidents(container){
    try{
      const params = new URLSearchParams(window.__currentFilters||{}).toString();
      const url = '../../PHP/residents.php'+(params?('?action=list&'+params):'?action=list');
      const data = await jsonFetch(url);
      const rows = data.data||[];
      // cache for edit modal prefill
      window.__residentsCache = rows.reduce((m,r)=>{ m[r.id]=r; return m; },{});
      const table = qs('table', container); const tbody = qs('tbody', table);
      const calcAge = (bd)=>{
        if(!bd) return '';
        try{ const d=new Date(bd); if(isNaN(d)) return ''; const t=new Date(); let a=t.getFullYear()-d.getFullYear(); const m=t.getMonth()-d.getMonth(); if(m<0 || (m===0 && t.getDate()<d.getDate())) a--; return a; }catch(_){return ''}
      };
      tbody.innerHTML = rows.map(r=>{
        const age = (r.age!=null && r.age!=='') ? r.age : (r.age_calc!=null? r.age_calc : calcAge(r.birth_date));
        const purok = r.purok_name || r.purok_id || '';
        const contact = r.contact_number || '';
        const voterReg = (r.voter_registered || '') === 'Yes' ? 'Yes' : (r.voter_registered || '');
        const voterStatus = r.voter_status || '';
        return `<tr>
          <td>${r.id}</td><td>${r.full_name||''}</td><td>${age||''}</td><td>${r.gender||''}</td>
          <td>${purok}</td><td>${contact}</td><td>${voterReg}</td><td>${voterStatus}</td>
          <td>
            <button data-edit="${r.id}">Edit</button>
            <button data-del="${r.id}">Delete</button>
          </td>
        </tr>`;
      }).join('');
      // edit handlers
      qsa('button[data-edit]', container).forEach(btn=>{
        btn.addEventListener('click', ()=>{
          const id = btn.dataset.edit; const r = window.__residentsCache && window.__residentsCache[id]; if(!r) return;
          openResidentEditModal(r);
        });
      });
      // delete handlers
      qsa('button[data-del]', container).forEach(btn=>{
        btn.addEventListener('click', async ()=>{
          if (!confirm('Delete resident '+btn.dataset.del+'?')) return;
          await jsonFetch('../../PHP/residents.php?action=delete', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: btn.dataset.del }) });
          loadResidents(container);
        });
      });
    } catch(e){ qs('.error',container).textContent = e.message; }
  }
  function bindResidents(container){
    const form = qs('form', container);
    if (form){
      // household select filtered by purok
      const purokInput = qs('input[name="purok_id"]', form);
      const hhSelect = qs('select[name="household_id"]', form);
      async function populateHouseholds(pid){
        if (!hhSelect) return; hhSelect.innerHTML = '<option value="">Select Household (optional)</option>';
        try{
          const url = pid ? ('../../PHP/households.php?action=list&purok_id='+encodeURIComponent(pid)) : '../../PHP/households.php?action=list';
          const resp = await jsonFetch(url);
          const rows = (resp && resp.data) || [];
          hhSelect.innerHTML = '<option value="">Select Household (optional)</option>' + rows.map(h=>`<option value="${h.id}">${h.household_no||h.id}</option>`).join('');
        }catch(e){ /* ignore */ }
      }
      if (purokInput && hhSelect){
        purokInput.addEventListener('change', ()=>populateHouseholds(purokInput.value));
        populateHouseholds(purokInput.value);
      } else if (hhSelect) {
        // No purok input (e.g., Purok dashboard) - rely on server-side scope
        populateHouseholds(null);
      }
      // Auto-compute age when birth_date changes
      const bd = qs('input[name="birth_date"]', form);
      const ageInput = qs('input[name="age"]', form);
      if (bd && ageInput){
        bd.addEventListener('change', ()=>{
          const v = bd.value; if(!v) return; try{ const d=new Date(v); if(isNaN(d)) return; const t=new Date(); let a=t.getFullYear()-d.getFullYear(); const m=t.getMonth()-d.getMonth(); if(m<0 || (m===0 && t.getDate()<d.getDate())) a--; ageInput.value = a; }catch(_){/* ignore */}
        });
      }
      // Auto-fill full_name in real time from name parts
      const ln = qs('input[name="last_name"]', form);
      const fn = qs('input[name="first_name"]', form);
      const mn = qs('input[name="middle_name"]', form);
      const full = qs('input[name="full_name"]', form);
      function syncFull(){
        if (!full) return;
        const l = (ln && ln.value ? ln.value.trim() : '');
        const f = (fn && fn.value ? fn.value.trim() : '');
        const m = (mn && mn.value ? mn.value.trim() : '');
        full.value = (l && f) ? (l + ', ' + f + (m ? (' ' + m) : '')) : '';
      }
      [ln, fn, mn].forEach(el=>{ if (el) el.addEventListener('input', syncFull); });
      syncFull();
      form.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd = new FormData(form); const obj = Object.fromEntries(fd.entries());
        // Compose full_name if missing but name parts exist
        if ((!obj.full_name || obj.full_name.trim()==='') && (obj.last_name || obj.first_name)){
          const ln=(obj.last_name||'').trim(); const fn=(obj.first_name||'').trim(); const mn=(obj.middle_name||'').trim();
          if (ln && fn) obj.full_name = ln + ', ' + fn + (mn?(' '+mn):'');
        }
        // Map voter_status dropdown to voter_registered flag
        if (obj.voter_status === 'Registered') obj.voter_registered = 1;
        else if (obj.voter_status === 'Not Registered') obj.voter_registered = 0;
        try{
          await jsonFetch('../../PHP/residents.php?action=create', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj) });
          form.reset();
          loadResidents(container);
        }catch(err){ alert('Create failed: '+err.message); }
      });
    }
    // toggle Add Resident form visibility
    const addCard = container.querySelector('[data-add-resident-card]');
    const addBtn = document.getElementById('btnAddResident');
    if (addCard && addBtn){
      addBtn.addEventListener('click', ()=>{
        const cur = addCard.style.display;
        addCard.style.display = (!cur || cur === 'none') ? 'block' : 'none';
      });
    }

    // local filters for residents (Purok leader: gender/age/voter, Admin: purok)
    const adminPurokSel = document.getElementById('adminPurokFilter');
    if (adminPurokSel){
      (async ()=>{
        try{
          const data = await jsonFetch('../../PHP/puroks.php');
          const rows = (data && data.data) || [];
          adminPurokSel.innerHTML = '<option value="">All</option>' + rows.map(p=>`<option value="${p.id}">${p.name||p.id}</option>`).join('');
        }catch(_){ /* ignore */ }
      })();
    }
    const voterSel = document.getElementById('purokVoterFilter');
    const genderSel = document.getElementById('resFilterGender');
    const ageSel = document.getElementById('resFilterAge');
    const applyFilters = ()=>{
      window.__currentFilters = window.__currentFilters || {};
      // reset relevant filters
      delete window.__currentFilters.gender;
      delete window.__currentFilters.age_bucket;
      delete window.__currentFilters.voter;
      delete window.__currentFilters.voter_only;
      delete window.__currentFilters.purok_id;

      if (genderSel && genderSel.value){
        window.__currentFilters.gender = genderSel.value;
      }
      if (ageSel && ageSel.value){
        window.__currentFilters.age_bucket = ageSel.value;
      }
      if (voterSel && voterSel.value){
        window.__currentFilters.voter = voterSel.value; // 'registered' | 'not_registered'
        window.__currentFilters.voter_only = 1;
      }
      if (adminPurokSel && adminPurokSel.value){
        window.__currentFilters.purok_id = adminPurokSel.value;
      }
      loadResidents(container);
    };

    [voterSel, genderSel, ageSel, adminPurokSel].forEach(el=>{ if (el) el.addEventListener('change', applyFilters); });

    loadResidents(container);
  }

  // Edit modal logic
  function openResidentEditModal(row){
    const modal = document.getElementById('residentEditModal'); if (!modal) return;
    const form = modal.querySelector('form'); if (!form) return;
    // fill fields
    const set = (n,v)=>{ const el=form.querySelector(`[name="${n}"]`); if(!el) return; if(el.type==='checkbox'){ el.checked = (v===true || v==='Yes' || v===1); } else { el.value = v==null?'':v; } };
    const fields = ['id','purok_id','household_id','last_name','first_name','middle_name','full_name','birth_date','age','gender','civil_status','address','contact_number','email','occupation','educational_attainment','religion','citizenship','blood_type','voter_status'];
    fields.forEach(f=> set(f, row[f]));
    // Real-time sync of full_name in edit modal
    const ln = form.querySelector('input[name="last_name"]');
    const fn = form.querySelector('input[name="first_name"]');
    const mn = form.querySelector('input[name="middle_name"]');
    const full = form.querySelector('input[name="full_name"]');
    function syncFullEdit(){
      if (!full) return;
      const l = (ln && ln.value ? ln.value.trim() : '');
      const f = (fn && fn.value ? fn.value.trim() : '');
      const m = (mn && mn.value ? mn.value.trim() : '');
      full.value = (l && f) ? (l + ', ' + f + (m ? (' ' + m) : '')) : '';
    }
    [ln, fn, mn].forEach(el=>{ if (el) el.addEventListener('input', syncFullEdit); });
    syncFullEdit();
    // populate households for purok and select current
    const hhSelect = form.querySelector('select[name="household_id"]');
    (async ()=>{
      if (hhSelect && row.purok_id){
        try{
          const resp = await jsonFetch('../../PHP/households.php?action=list&purok_id='+encodeURIComponent(row.purok_id));
          const rows = (resp && resp.data) || [];
          hhSelect.innerHTML = '<option value="">Select Household (optional)</option>' + rows.map(h=>`<option value="${h.id}">${h.household_no||h.id}</option>`).join('');
          if (row.household_id) hhSelect.value = row.household_id;
        }catch(e){ /* ignore */ }
      }
    })();
    // age auto from birth_date
    const bd = form.querySelector('input[name="birth_date"]'); const ageInput = form.querySelector('input[name="age"]');
    if (bd && ageInput){
      bd.addEventListener('change', ()=>{
        const v = bd.value; if(!v) return; try{ const d=new Date(v); if(isNaN(d)) return; const t=new Date(); let a=t.getFullYear()-d.getFullYear(); const m=t.getMonth()-d.getMonth(); if(m<0 || (m===0 && t.getDate()<d.getDate())) a--; ageInput.value = a; }catch(_){}}
      );
    }
    // submit handler
    const onSubmit = async (e)=>{
      e.preventDefault();
      const fd = new FormData(form); const obj = Object.fromEntries(fd.entries());
      if ((!obj.full_name || obj.full_name.trim()==='') && (obj.last_name || obj.first_name)){
        const ln=(obj.last_name||'').trim(); const fn=(obj.first_name||'').trim(); const mn=(obj.middle_name||'').trim(); if (ln && fn) obj.full_name = ln + ', ' + fn + (mn?(' '+mn):'');
      }
      // Map voter_status dropdown to voter_registered flag
      if (obj.voter_status === 'Registered') obj.voter_registered = 1;
      else if (obj.voter_status === 'Not Registered') obj.voter_registered = 0;
      try{
        await jsonFetch('../../PHP/residents.php?action=update', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj) });
        closeResidentEditModal();
        // reload lists in all sections present
        const r = document.querySelector('#sec-residents'); if (r) loadResidents(r);
      }catch(err){ alert('Update failed: '+err.message); }
    };
    form.addEventListener('submit', onSubmit, { once: true });
    // close actions
    modal.querySelector('[data-close]')?.addEventListener('click', closeResidentEditModal, { once: true });
    modal.style.display='flex';
  }
  function closeResidentEditModal(){ const modal = document.getElementById('residentEditModal'); if (modal) modal.style.display='none'; }

  // User edit modal logic
  function openUserEditModal(row){
    const modal = document.getElementById('userEditModal'); if (!modal) return;
    const form = modal.querySelector('#userEditForm'); if (!form) return;
    const set = (n,v)=>{ const el=form.querySelector(`[name="${n}"]`); if(el) el.value = (v==null?'':v); };
    set('id', row.id);
    set('full_name', row.full_name||'');
    set('role', row.role||'');
    set('status', row.status||'');
    set('purok_id', row.purok_id||'');
    const onSubmit = async (e)=>{
      e.preventDefault();
      const fd = new FormData(form); const obj = Object.fromEntries(fd.entries());
      try{
        await jsonFetch('../../PHP/users_admin.php?action=update', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj) });
        closeUserEditModal();
        const u = document.querySelector('#sec-users'); if (u) loadUsers(u);
      }catch(err){ alert('Update failed: '+err.message); }
    };
    form.addEventListener('submit', onSubmit, { once: true });
    modal.querySelector('[data-user-close]')?.addEventListener('click', closeUserEditModal, { once: true });
    modal.style.display='flex';
  }
  function closeUserEditModal(){ const modal = document.getElementById('userEditModal'); if (modal) modal.style.display='none'; }

  // Households UI (list/add/delete)
  async function loadHouseholds(container){
    try{
      const params = new URLSearchParams(window.__currentFilters||{}).toString();
      const url='../../PHP/households.php'+(params?('?action=list&'+params):'?action=list');
      const data = await jsonFetch(url);
      const rows = data.data||[];
      const tbody = qs('tbody', container);
      tbody.innerHTML = rows.map(h=>`<tr><td>${h.id}</td><td>${h.household_no||''}</td><td>${h.address||''}</td><td><button data-hdel="${h.id}">Delete</button></td></tr>`).join('');
      qsa('button[data-hdel]', container).forEach(btn=>{
        btn.addEventListener('click', async ()=>{
          if (!confirm('Delete household '+btn.dataset.hdel+'?')) return;
          await jsonFetch('../../PHP/households.php?action=delete', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: btn.dataset.hdel }) });
          loadHouseholds(container);
        });
      });
    }catch(e){ qs('.error',container).textContent = e.message; }
  }
  function bindHouseholds(container){
    const form = qs('form', container);
    if (form){
      form.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd = new FormData(form); const obj = Object.fromEntries(fd.entries());
        // Back-compat: map legacy input name to current schema
        if (!obj.household_no && obj.household_head_name) obj.household_no = obj.household_head_name;
        // keep UUID/string ids as-is
        try{ await jsonFetch('../../PHP/households.php?action=create', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj) }); form.reset(); loadHouseholds(container);}catch(err){ alert('Create failed: '+err.message); }
      });
    }
    loadHouseholds(container);
  }

  // Users admin (list/create/edit/deactivate/reactivate/delete/reset pw)
  async function loadUsers(container){
    try{
      const data = await jsonFetch('../../PHP/users_admin.php?action=list');
      const rows = data.data||[];
      const tbody = qs('tbody', container);
      tbody.innerHTML = rows.map(u=>{
        const isActive = (u.status === 'active');
        const actBtn = isActive
          ? `<button data-deact="${u.id}">Deactivate</button>`
          : `<button data-react="${u.id}">Reactivate</button>`;
        return `<tr>
          <td>${u.id}</td>
          <td>${u.username}</td>
          <td>${u.full_name||''}</td>
          <td>${u.role}</td>
          <td>${u.status}</td>
          <td>${u.purok_id||''}</td>
          <td>
            <button data-edit="${u.id}">Edit</button>
            ${actBtn}
            <button data-reset="${u.id}">Reset PW</button>
            <button data-del="${u.id}">Delete</button>
          </td>
        </tr>`;
      }).join('');

      // Edit via modal
      qsa('button[data-edit]', container).forEach(btn=>{
        btn.addEventListener('click', ()=>{
          const id = btn.dataset.edit;
          const row = rows.find(r=>String(r.id)===String(id));
          if (!row) return;
          openUserEditModal(row);
        });
      });
      // Deactivate
      qsa('button[data-deact]', container).forEach(btn=>{
        btn.addEventListener('click', async ()=>{
          if (!confirm('Deactivate user '+btn.dataset.deact+'?')) return;
          await jsonFetch('../../PHP/users_admin.php?action=deactivate', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: btn.dataset.deact }) });
          loadUsers(container);
        });
      });
      // Reactivate
      qsa('button[data-react]', container).forEach(btn=>{
        btn.addEventListener('click', async ()=>{
          await jsonFetch('../../PHP/users_admin.php?action=reactivate', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: btn.dataset.react }) });
          loadUsers(container);
        });
      });
      // Reset password
      qsa('button[data-reset]', container).forEach(btn=>{
        btn.addEventListener('click', async ()=>{
          const pw = prompt('Enter new password:'); if (pw===null || pw==='') return;
          await jsonFetch('../../PHP/users_admin.php?action=reset_password', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: btn.dataset.reset, password: pw }) });
          alert('Password reset.');
        });
      });
      // Delete
      qsa('button[data-del]', container).forEach(btn=>{
        btn.addEventListener('click', async ()=>{
          if (!confirm('Delete user '+btn.dataset.del+'? This cannot be undone.')) return;
          await jsonFetch('../../PHP/users_admin.php?action=delete', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: btn.dataset.del }) });
          loadUsers(container);
        });
      });
    }catch(e){ qs('.error',container).textContent = e.message; }
  }
  function bindUsers(container){
    const form = qs('form', container);
    if (form){
      const roleSel = qs('select[name="role"]', form);
      const purokInput = qs('input[name="purok_id"]', form);
      if (roleSel && purokInput){
        const applyReq = ()=>{ purokInput.required = (roleSel.value === 'purok'); };
        roleSel.addEventListener('change', applyReq);
        applyReq();
      }
      form.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const fd = new FormData(form); const obj = Object.fromEntries(fd.entries());
        // keep UUID/string ids as-is if provided
        if (obj.role === 'purok' && (!obj.purok_id || obj.purok_id.trim()==='')){ alert('Please provide Purok ID for a purok user.'); return; }
        try{ await jsonFetch('../../PHP/users_admin.php?action=create', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj) }); form.reset(); loadUsers(container);}catch(err){ alert('Create user failed: '+err.message); }
      });
    }
    loadUsers(container);
  }

  // Activity feed
  async function loadActivity(container){
    const errBox = qs('.error', container);
    async function fetchAndRender(){
      try{
        const params = new URLSearchParams();
        params.set('limit','20');
        const start = qs('#actStart', container);
        const end = qs('#actEnd', container);
        const user = qs('#actUser', container);
        const actionSel = qs('#actAction', container);
        if (start && start.value) params.set('start_date', start.value);
        if (end && end.value) params.set('end_date', end.value);
        if (user && user.value) params.set('username', user.value);
        if (actionSel && actionSel.value) params.set('action', actionSel.value);
        const url = '../../PHP/activity_feed.php' + (params.toString() ? ('?' + params.toString()) : '');
        const data = await jsonFetch(url);
        const rows = data.data||[];
        const list = qs('tbody', container);
        list.innerHTML = rows.map(r=>`<tr><td>${r.created_at}</td><td>${r.username||''}</td><td>${r.role||''}</td><td>${r.action_type}:${r.entity}</td><td>${r.entity_id||''}</td></tr>`).join('');
        if (errBox) errBox.textContent = '';
      }catch(e){ if (errBox) errBox.textContent = e.message; }
    }

    const btnFilter = qs('#actFilterBtn', container);
    const btnClear = qs('#actClearBtn', container);
    if (btnFilter){
      btnFilter.addEventListener('click', (e)=>{ e.preventDefault(); fetchAndRender(); });
    }
    if (btnClear){
      btnClear.addEventListener('click', (e)=>{ e.preventDefault();
        const start = qs('#actStart', container);
        const end = qs('#actEnd', container);
        const user = qs('#actUser', container);
        const actionSel = qs('#actAction', container);
        if (start) start.value = '';
        if (end) end.value = '';
        if (user) user.value = '';
        if (actionSel) actionSel.value = '';
        fetchAndRender();
      });
    }

    fetchAndRender();
  }

  ready(()=>{
    bindNav();
    // attach section-specific behaviors if containers exist
    const r = qs('#sec-residents'); if (r) bindResidents(r);
    const h = qs('#sec-households'); if (h) bindHouseholds(h);
    const u = qs('#sec-users'); if (u) bindUsers(u);
    const a = qs('#sec-activity'); if (a) loadActivity(a);
    // Profile settings (Purok dashboard)
    const prof = qs('#sec-profile');
    if (prof){
      const err = qs('.error', prof);
      const fp = qs('#form-profile', prof);
      const pw = qs('#form-password', prof);
      const fph = qs('#form-photo', prof);
      const img = qs('#profPhoto', prof);
      (async ()=>{
        try{
          const me = await jsonFetch('../../PHP/users_profile.php?action=me');
          if (me && me.ok && me.data){
            const f = fp; if (f) { const i=f.querySelector('[name="full_name"]'); if(i) i.value = me.data.full_name||''; }
            if (img) { img.src = (me.data.photo_url || '../../assets/images/logo.png'); }
          }
        }catch(e){ if(err) err.textContent = e.message; }
      })();
      // prevent native submits (we handle everything with one Update Profile button)
      if (fp){ fp.addEventListener('submit', (e)=>{ e.preventDefault(); }); }
      if (pw){ pw.addEventListener('submit', (e)=>{ e.preventDefault(); }); }
      if (fph){ fph.addEventListener('submit', (e)=>{ e.preventDefault(); }); }

      const updateAllBtn = document.getElementById('btnProfileUpdateAll');
      if (updateAllBtn){
        updateAllBtn.addEventListener('click', async ()=>{
          updateAllBtn.disabled = true;
          try{
            // 1) Basic profile
            if (fp){
              const fd = new FormData(fp); const obj = Object.fromEntries(fd.entries());
              await jsonFetch('../../PHP/users_profile.php?action=update', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj) });
            }
            // 2) Change password (only if fields filled)
            if (pw){
              const fdPw = new FormData(pw); const objPw = Object.fromEntries(fdPw.entries());
              const cur = (objPw.current_password||'').trim();
              const neu = (objPw.new_password||'').trim();
              if (cur && neu){
                await jsonFetch('../../PHP/users_profile.php?action=change_password', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(objPw) });
                pw.reset();
              }
            }
            // 3) Photo upload (only if file chosen)
            if (fph){
              const fileInput = fph.querySelector('input[name="photo"]');
              if (fileInput && fileInput.files && fileInput.files.length > 0){
                const fdPhoto = new FormData(fph);
                const res = await fetch('../../PHP/users_profile.php?action=upload_photo', { method:'POST', body: fdPhoto });
                const json = await res.json();
                if (!res.ok || json.ok===false) throw new Error(json.error||('HTTP '+res.status));
                if (img && json.photo_url) img.src = json.photo_url + '?t=' + Date.now();
              }
            }
            alert('Profile updated.');
          }catch(e){ alert('Update failed: '+e.message); }
          finally{ updateAllBtn.disabled = false; }
        });
      }
    }
    // default to overview
    if (qs('[data-section]')) showSection('sec-overview');
  });
})();
