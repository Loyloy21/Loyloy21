(function(){
  const ready = (fn)=> document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn);
  const LS_KEY = 'staff_filters_v1';
  let __allPuroks = [];
  let __debounce; const debounce = (fn,ms)=>{ return function(...args){ clearTimeout(__debounce); __debounce=setTimeout(()=>fn.apply(this,args), ms); } };

  function saveFilters(){ try{ localStorage.setItem(LS_KEY, JSON.stringify(window.__currentFilters||{})); }catch(_){} }
  function loadSaved(){ try{ return JSON.parse(localStorage.getItem(LS_KEY)||'{}'); }catch(_){ return {}; } }

  function applySavedToControls(saved){
    const setVal = (id,val)=>{ const el=document.getElementById(id); if(el && val!=null){ el.value = val; } };
    setVal('purokFilter', saved.purok_id||'');
    setVal('genderFilter', saved.gender||'');
    setVal('ageFilter', saved.age_bucket||'');
    setVal('voterFilter', saved.voter||'');
  }

  async function loadPuroks(){
    try {
      const res = await fetch('../../PHP/puroks.php', { cache: 'no-store' });
      const json = await res.json();
      if (json.ok) __allPuroks = json.data || []; else __allPuroks = [];
      renderPurokOptions();
      // re-apply saved purok after options load
      const saved = loadSaved();
      if (saved.purok_id){ const sel=document.getElementById('purokFilter'); if(sel){ sel.value = saved.purok_id; } }
    } catch(e) { __allPuroks = []; renderPurokOptions(); }
  }

  function renderPurokOptions(filterText=''){
    const select = document.getElementById('purokFilter'); if (!select) return;
    const txt = filterText.trim().toLowerCase();
    select.innerHTML = '';
    const addOpt=(v, t)=>{ const o=document.createElement('option'); o.value=v; o.textContent=t; select.appendChild(o); };
    addOpt('', 'All Puroks');
    const rows = __allPuroks.filter(p=> !txt || (p.name||'').toLowerCase().includes(txt));
    if (rows.length === 0) { const o=document.createElement('option'); o.textContent='No matches'; o.disabled=true; select.appendChild(o); return; }
    rows.forEach(p=> addOpt(p.id, p.name));
  }

  function currentParams(){
    const p = {};
    const purok = document.getElementById('purokFilter');
    const gender = document.getElementById('genderFilter');
    const age = document.getElementById('ageFilter');
    const ageMin = document.getElementById('ageMin');
    const ageMax = document.getElementById('ageMax');
    const voter = document.getElementById('voterFilter');
    const voterOnly = document.getElementById('voterToggle');
    const startDate = document.getElementById('startDate');
    const endDate = document.getElementById('endDate');
    if (purok && purok.value) p.purok_id = purok.value;
    if (gender && gender.selectedOptions && gender.multiple){
      const vals = Array.from(gender.selectedOptions).map(o=>o.value).filter(Boolean);
      if (vals.length) p.genders = vals.join(',');
    } else if (gender && gender.value) {
      p.gender = gender.value;
    }
    if (age && age.value) p.age_bucket = age.value;
    if (ageMin && ageMin.value) p.age_min = ageMin.value;
    if (ageMax && ageMax.value) p.age_max = ageMax.value;
    if (voter && voter.value) p.voter = voter.value; // 'registered' | 'not_registered'
    if (voterOnly && voterOnly.checked) p.voter_only = 1;
    if (startDate && startDate.value) p.start_date = startDate.value;
    if (endDate && endDate.value) p.end_date = endDate.value;
    window.__currentFilters = p; // for auto-refresh
    saveFilters();
    syncReportLinks(p);
    return p;
  }

  function syncReportLinks(params){
    const qs = new URLSearchParams(params).toString();
    const csv = document.querySelector('a[href*="export_csv.php"]');
    const rpt = document.querySelector('a[href*="export_report.php"]');
    if (csv) csv.href = '../../PHP/export_csv.php' + (qs?('?'+qs):'');
    if (rpt) rpt.href = '../../PHP/export_report.php' + (qs?('?'+qs):'');
  }

  function bindFilters(){
    const ids = ['purokFilter','genderFilter','ageFilter','ageMin','ageMax','voterFilter','voterToggle','startDate','endDate'];
    const onChange = debounce(()=>{
      const params = currentParams();
      if (window.BrgyDashboard) window.BrgyDashboard.fetchStats(params);
    }, 200);
    ids.forEach(id=>{ const el=document.getElementById(id); if (el){ el.addEventListener('change', onChange); } });
    // Purok search filter
    const search = document.getElementById('purokSearch');
    if (search){ search.addEventListener('input', debounce(()=>{ renderPurokOptions(search.value||''); }, 150)); }
    // Clear filters
    const clearBtn = document.getElementById('clearFilters');
    if (clearBtn){ clearBtn.addEventListener('click', (e)=>{ e.preventDefault();
      ['purokFilter','genderFilter','ageFilter','ageMin','ageMax','voterFilter','purokSearch','startDate','endDate'].forEach(id=>{ const el=document.getElementById(id); if(!el) return; if (el.tagName==='SELECT') { if (el.multiple) Array.from(el.options).forEach(o=>o.selected=false); else el.selectedIndex=0; } else el.value=''; });
      const vt=document.getElementById('voterToggle'); if (vt) vt.checked=false;
      renderPurokOptions('');
      const params = currentParams();
      if (window.BrgyDashboard) window.BrgyDashboard.fetchStats(params);
    }); }
    // initial param sync
    currentParams();
  }

  function bindExport(){
    const btn = document.getElementById('exportBtn');
    if (!btn) return;
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      const params = currentParams();
      const qs = new URLSearchParams(params).toString();
      const url = '../../PHP/export_csv.php' + (qs ? ('?' + qs) : '');
      window.location.href = url;
    });
  }

  ready(()=>{
    loadPuroks().then(()=>{
      // restore saved filter selections and fetch
      const saved = loadSaved();
      applySavedToControls(saved);
      const params = currentParams();
      if (window.BrgyDashboard) window.BrgyDashboard.fetchStats(params);
    });
    bindFilters();
    bindExport();
    // Chart download buttons
    document.querySelectorAll('.dlChart').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = btn.getAttribute('data-target'); const cvs = document.getElementById(id); if (!cvs) return;
        const link = document.createElement('a'); link.href = cvs.toDataURL('image/png'); link.download = id + '.png'; link.click();
      });
    });
    // CSV column picks
    document.querySelectorAll('.colPick').forEach(ch=>{
      ch.addEventListener('change', ()=> syncReportLinks(window.__currentFilters||{}));
    });
  });
})();
